/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.cell;

import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.border.EmptyBorder;

/**
 *
 * @author TarJ
 */
public class ActionButton extends JButton {
    
    public ActionButton() {
        setBorder(new EmptyBorder(3, 3, 3, 3));
        setContentAreaFilled(false);
    }
}
