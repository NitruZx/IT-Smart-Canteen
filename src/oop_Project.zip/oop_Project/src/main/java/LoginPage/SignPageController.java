package LoginPage;

import Database.DB;
import Interface.updateInfo;
import com.formdev.flatlaf.themes.FlatMacLightLaf;

import javax.swing.*;
import java.awt.event.*;
import java.sql.*;


public class SignPageController implements ActionListener {
    private SignUpGUI signUpGUI;
    public UserInfo user;
    private SignUpPageModel signUpPageModel;

    public SignPageController() {
        signUpGUI = new SignUpGUI();
        signUpPageModel = new SignUpPageModel();
        signUpGUI.signupBtn.addActionListener(this);
        signUpGUI.backBtn.addActionListener(this);
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == signUpGUI.signupBtn) {
            registerUser();
        } else if (e.getSource().equals(signUpGUI.backBtn)) {
            new Main();
            signUpGUI.frame.dispose();
        }
    }

    private void registerUser() {
        String name = signUpGUI.nameField.getText();
        String email = signUpGUI.emailField.getText();
        String password = String.valueOf(signUpGUI.passField1.getPassword());
        String password2 = String.valueOf(signUpGUI.passField2.getPassword());

        if (name.isEmpty() || email.isEmpty() || password.isEmpty() || password2.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Please enter all fields", "Sign-up", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (name.length() < 4) {
            JOptionPane.showMessageDialog(null, "Username must at least 4 character!!!", "Sign-up", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (password.length() < 6) {
            JOptionPane.showMessageDialog(null, "Password must at least 6 character!!!", "Sign-up", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (!password.equals(password2)) {
            JOptionPane.showMessageDialog(null, "Comfirm password does not match", "Sign-up", JOptionPane.ERROR_MESSAGE);
            return;
        }

        user = signUpPageModel.addUserToDB(name, email, password);
        if (user != null) {
            JOptionPane.showMessageDialog(null, "Create Account Success!", "Success", JOptionPane.PLAIN_MESSAGE);
        } else {
            System.out.println("Failed to create account");
        }
    }

    public static void main(String[] args) {
        try {
//            UIManager.setLookAndFeel(new Flat);
        } catch (Exception e) {
            e.printStackTrace();
        }
        new SignPageController();
    }


}
