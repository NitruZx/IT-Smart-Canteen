package LoginPage;

import AdminPage.AdminPageController;
import ClientPage.ClientController;
import Database.DB;
import ian.PassFieldCtm;
import ian.CustomField;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class SellerPanel implements ActionListener {
    private JPanel centerMain, buttPanel, textPanel, emptyPanel;
    private JButton loginButt;
    private CustomField username;
    private PassFieldCtm password;
    private Color color = new Color(145, 3, 216);
    private LoginModel loginModel;
    public SellerPanel() {
        loginModel = new LoginModel();
        centerMain = new JPanel();
        centerMain.setLayout(new GridLayout(3, 1));

        textPanel = new JPanel();
        textPanel.setLayout(new GridLayout(2, 1));
        buttPanel = new JPanel();

        username = new CustomField();
        password = new PassFieldCtm();
        username.setLabelText("Admin user");username.setLineColor(color);username.setSelectionColor(new Color(188, 142, 218));
        password.setLabelText("Password");password.setLineColor(color);password.setSelectionColor(new Color(188, 142, 218));

        loginButt = new JButton("Login");
        buttPanel.add(loginButt);
        textPanel.setBorder(new EmptyBorder(10, 30, 10, 30));
        textPanel.add(username);textPanel.add(password);

        centerMain.add(textPanel);centerMain.add(buttPanel);
        centerMain.setBorder(new EmptyBorder(80, 60, 20, 60));
        loginButt.addActionListener(this);
    }

    public JPanel getCenterMain() {
        return centerMain;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == loginButt) {
            if (loginModel.login(username.getText(), String.valueOf(password.getPassword()), "SELECT * FROM admin WHERE Name=? LIMIT 1")) {
                JOptionPane.showMessageDialog(null, "Login Success", "Login", JOptionPane.PLAIN_MESSAGE);
                AdminPageController adminPage = new AdminPageController("Admin");
            }
        }
    }


    public void addAdmin(String name, String password) {
        String hashPass = DB.getHash(password);
        try {
            Connection conn = DB.mycon();
            PreparedStatement pst = conn.prepareStatement(" SELECT * FROM users WHERE Name=? LIMIT 1");
            pst.setString(1, name);
            ResultSet rs = pst.executeQuery();
            if (!rs.next()) {
                Statement stmt = conn.createStatement();
                String sql = "INSERT INTO admin (name, password) VALUES (?, ?)";
                PreparedStatement preparedStatement = conn.prepareStatement(sql);
                preparedStatement.setString(1, name);
                preparedStatement.setString(2, hashPass);
                preparedStatement.executeUpdate();

                stmt.close();
                conn.close();
                JOptionPane.showMessageDialog(null, "Success", "title", JOptionPane.PLAIN_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "Username already exists!", "Sign-up", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
