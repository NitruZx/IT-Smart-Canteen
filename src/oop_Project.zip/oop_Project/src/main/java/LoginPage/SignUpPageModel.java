package LoginPage;

import Database.DB;
import Interface.updateInfo;

import javax.swing.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class SignUpPageModel {
//    public UserInfo userInfo;
//    public SignUpPageModel() {
//        userInfo = new UserInfo();
//    }

    public static void changePassword(String name, String email, String oldPass, String newPass, String tableName, String passCol) {
        String hashOldPass = DB.getHash(oldPass);
        if (oldPass.equals(newPass)) {
            JOptionPane.showMessageDialog(null, "New password can't be the same as old", "Changepassword", JOptionPane.ERROR_MESSAGE);
            System.out.println("Here?");
            return;
        }
        try {
            Connection conn = DB.mycon();
            PreparedStatement pst = conn.prepareStatement("SELECT * FROM "+tableName+" WHERE Name="+"'"+name+"'"+" AND Email="+"'"+email+"'"+" LIMIT 1");
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                if (DB.checkPassword(hashOldPass, rs.getString("Password"))) {
                    String hashNewPass = DB.getHash(newPass);
                    updateInfo.runSQLQuery("UPDATE "+tableName+" SET "+passCol+" WHERE name="+"'"+name+"'", "Password change FAILED");
                    JOptionPane.showMessageDialog(null, "Update password success!", "Update Password", JOptionPane.PLAIN_MESSAGE);
                    System.out.println("finished");
                } else {
                    System.out.println("what");
                }
            } else {
                System.out.println("Email not found");
            }
            rs.close();
            pst.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void passChange(String sql, String updateSQL, String newPass) {
        try {
            Connection conn = DB.mycon();
            PreparedStatement pst = conn.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                String hashNewPass = DB.getHash(newPass);
                if (!DB.checkPassword(hashNewPass, rs.getString("Password"))) {
                    System.out.println("Here");
                    updateInfo.runSQLQuery(updateSQL, "Error");
                    JOptionPane.showMessageDialog(null, "Update password success!", "Update Password", JOptionPane.PLAIN_MESSAGE);
                } else {
                    System.out.println("Here2");
                    JOptionPane.showMessageDialog(null, "New password can't be the same as old", "", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                System.out.println("AHEHE");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public UserInfo addUserToDB(String name, String email, String password) {
        UserInfo user = null;
        String hashPass = DB.getHash(password);
        try {
            Connection conn = DB.mycon();
            PreparedStatement pst = conn.prepareStatement(" SELECT * FROM users WHERE Name=? LIMIT 1");
            pst.setString(1, name);
            ResultSet rs = pst.executeQuery();
            if (!rs.next()) {
                Statement stmt = conn.createStatement();
                String sql = "INSERT INTO users (Name, Email, Password) VALUES (?, ?, ?)";
                PreparedStatement preparedStatement = conn.prepareStatement(sql);
                preparedStatement.setString(1, name);
                preparedStatement.setString(2, email);
                preparedStatement.setString(3, hashPass);

                int addedRows = preparedStatement.executeUpdate();
                if (addedRows > 0) {
                    user = new UserInfo();
                    user.setName(name);
                    user.setEmail(email);
                    user.setPassword(hashPass);
                }

                stmt.close();
                conn.close();
            } else {
                JOptionPane.showMessageDialog(null, "Username already exists!", "Sign-up", JOptionPane.ERROR_MESSAGE);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return user;
    }

//    public UserInfo getUserInfo() {
//        return userInfo;
//    }
//
//    public void setUserInfo(UserInfo userInfo) {
//        this.userInfo = userInfo;
//    }

//    public static void main(String[] args) {
//        new SignPageController();
//    }
}
