/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AdminPage;

import static AdminPage.AdminPageController.showGlassPane;
import DataCall2.MenuKeeping2;
import Database.DB;
import Database.Order;
import Interface.updateInfo;
import Main.Bill;
import Queuefunc.QueueTable;
import com.cell.TableActionCellEditor;
import com.cell.TableActionCellRender;
import com.cell.TableActionEvent;
import java.io.ByteArrayInputStream;
import java.io.ObjectInputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.SwingWorker;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author TarJ
 */
public class AdminModel {

    public static ArrayList<String[]> billList;

//    public static ArrayList<Order> menuList(String sql) {
//        ArrayList<Order> menusList = new ArrayList<>();
//        billList = new ArrayList<>();
//        try {
//            Connection con = DB.mycon();
//            PreparedStatement pst = con.prepareStatement(sql);
//            ResultSet rs = pst.executeQuery();
//
//            Order menu;
//            while (rs.next()) {
//                int queue = rs.getInt("id");
//                Timestamp time = rs.getObject("time", Timestamp.class);
//                byte[] st = (byte[]) rs.getObject("menu");
//                ByteArrayInputStream baip = new ByteArrayInputStream(st);
//                ObjectInputStream ois = new ObjectInputStream(baip);
//                MenuKeeping2 menuKeep = (MenuKeeping2) ois.readObject();
//                String[] bill = menuKeep.billText(menuKeep.getTypeMenu(), menuKeep.getLineMenu(), menuKeep.getInd(), menuKeep.getEgg(), time.toString(), queue);
//                billList.add(bill);
//                menu = new Order(queue, time, menuKeep, rs.getString("name"));
//                menusList.add(menu);
//            }
//            pst.close();
//            rs.close();
//            con.close();
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return menusList;
//    }

    public static void showMenu() {
        TableActionEvent event = new TableActionEvent() {
            @Override
            public void onDelete(int row) {
            }

            @Override
            public void onView(int row) {
                String[] text = billList.get(row);
                Bill bill = new Bill(text);
            }
        };
        SwingWorker worker = new SwingWorker() {

            @Override
            protected Object doInBackground() throws Exception {
                showGlassPane(true);
                AdminMain.loadingDialog.setVisible(true);
                ArrayList<Order> list = updateInfo.menuList(" SELECT * FROM queue");
                QueueTable queueTable = new QueueTable();
                DefaultTableModel model = (DefaultTableModel) queueTable.table.getModel();
//        DefaultTableModel newModel = new DefaultTableModel(null, new String[]{"Queue", "Time", "Menu", "Name"});
                Object[] row = new Object[4];
                for (int i = 0; i < list.size(); i++) {
                    row[0] = String.format("%03d", list.get(i).getQueue());
                    row[1] = list.get(i).getTime().toString();
                    row[2] = list.get(i).getMenu().getTypeMenu();
                    row[3] = list.get(i).getName();
                    model.addRow(row);
                }
                AdminMain.queueTable.table.setModel(model);
                updateInfo.tableEvent(AdminMain.queueTable.table, 4, event);
                return null;
            }

            @Override
            protected void done() {
                showGlassPane(false);
                AdminMain.loadingDialog.dispose();
            }
        };
        worker.execute();

    }

    public void dequeue() {
        SwingWorker workder = new SwingWorker() {
            @Override
            protected Object doInBackground() throws Exception {
                AdminMain.deleteDialog.setVisible(true);
                try {
                    Connection con = DB.mycon();
                    String sql = "DELETE FROM queue LIMIT 1";
                    PreparedStatement pst = con.prepareStatement(sql);
                    pst.executeUpdate();
                    showMenu();
                } catch (Exception e) {
                    e.printStackTrace();
                }

                return null;
            }

            @Override
            protected void done() {
                AdminMain.deleteDialog.dispose();
            }

        };
        workder.execute();
    }

    public static void clearTable() {
        AdminMain.queueTable.table.setModel(new QueueTable().table.getModel());
    }

    public void setState(Boolean state) {
        AdminMain.state = state;
        try {
            Connection con = DB.mycon();
            String sql = "UPDATE res_state SET state=? WHERE name=?";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setBoolean(1, state);
            pst.setString(2, "smartcanteen");
            pst.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static boolean stateCheck() {
        try {
            Connection con = DB.mycon();
            String sql = " SELECT * FROM res_state WHERE name=?";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, "smartcanteen");
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                boolean state = rs.getBoolean("state");
                return state;
            }
            rs.close();
            pst.close();
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean resetQueue() {
        int option = JOptionPane.showOptionDialog(null, "Reseting Queue?", "Confirm", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, null, 0);
        int count = 0;
        if (option == 0) {
            try {
                Connection con = DB.mycon();
                PreparedStatement ps = con.prepareStatement("SELECT id FROM queue LIMIT 1");
                ResultSet rs = ps.executeQuery();
                if (!rs.next()) {
                    String sql = "ALTER TABLE queue AUTO_INCREMENT = 1";
                    PreparedStatement pst = con.prepareStatement(sql);
                    pst.executeUpdate();
                    System.out.println("reseting");
                    return true;
                } else {
                    JOptionPane.showMessageDialog(null, "Queue is not empty", "Error", JOptionPane.ERROR_MESSAGE);
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        } 
        return false;
    }

}
