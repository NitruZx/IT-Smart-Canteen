/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Interface;

import AdminPage.AdminModel;
import static AdminPage.AdminModel.billList;
import ClientPage.ClientController;
import ClientPage.ClientModel;
import DataCall2.MenuKeeping2;
import Database.DB;
import Database.Order;
import com.cell.TableActionCellEditor;
import com.cell.TableActionCellRender;
import com.cell.TableActionEvent;
import java.awt.Font;
import java.io.ByteArrayInputStream;
import java.io.ObjectInputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;

/**
 *
 * @author TarJ
 */
public abstract class updateInfo {

    public static void book(int queue, MenuKeeping2 noodle, String name) {
        JLabel text = new JLabel("ยืนยันการจองหรือไม่");
        text.setFont(new Font("TH SarabunPSK", Font.BOLD, 18));
        int option = JOptionPane.showOptionDialog(null, text, "Confirm", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, null, 0);
        if (option == 0) {
            Order order = null;
            try {
                Connection con = DB.mycon();
                PreparedStatement pst = con.prepareStatement("INSERT INTO queue (queue, time, menu, name) VALUES (?, ?, ?, ?)");
                PreparedStatement pst2 = con.prepareStatement("INSERT INTO admin_his (time, menu, name) VALUES (?, ?, ?)");
                Timestamp timestamp = new java.sql.Timestamp(new java.util.Date().getTime());
                pst.setInt(1, queue);
                pst.setTimestamp(2, timestamp);
                pst.setObject(3, noodle);
                pst.setString(4, name);

                pst2.setTimestamp(1, timestamp);
                pst2.setObject(2, noodle);
                pst2.setString(3, name);
                int addedRows = pst.executeUpdate();
                pst2.executeUpdate();

                if (addedRows > 0) {
                    order = new Order();
                    order.setQueue(queue);
                    order.setTime(timestamp);
                    order.setMenu(noodle);
                    order.setName(name);
                }

                pst.close();
                con.close();
            } catch (Exception e) {
                e.printStackTrace();
            }

        } 
    }

    public static void runSQLQuery(String sql, String errorString) {
        try {
            Connection con = DB.mycon();
            PreparedStatement pst = con.prepareStatement(sql);
            pst.executeUpdate();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, errorString, "", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void tableEvent(JTable table, int column, TableActionEvent tableEvent) {

        table.getColumnModel().getColumn(column).setCellRenderer(new TableActionCellRender());
        table.getColumnModel().getColumn(column).setCellEditor(new TableActionCellEditor(tableEvent));
    }

    public static ArrayList<Order> menuList(String sql) {
        ArrayList<Order> menusList = new ArrayList<>();
        billList = new ArrayList<>();
        try {
            Connection con = DB.mycon();
            PreparedStatement pst = con.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();

            Order menu;
            while (rs.next()) {
                int queue = rs.getInt("id");
                Timestamp time = rs.getObject("time", Timestamp.class);
                byte[] st = (byte[]) rs.getObject("menu");
                ByteArrayInputStream baip = new ByteArrayInputStream(st);
                ObjectInputStream ois = new ObjectInputStream(baip);
                MenuKeeping2 menuKeep = (MenuKeeping2) ois.readObject();
                String[] bill = menuKeep.billText(menuKeep.getTypeMenu(), menuKeep.getLineMenu(), menuKeep.getInd(), menuKeep.getEgg(), time.toString(), queue);
                billList.add(bill);
                if (!(ClientModel.ClientbillList == null)) {
                    ClientModel.ClientbillList.add(bill);
                }
                if (!(AdminModel.billList == null)) {
                    AdminModel.billList.add(bill);
                }
                menu = new Order(queue, time, menuKeep, rs.getString("name"));
                menusList.add(menu);
            }
            pst.close();
            rs.close();
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return menusList;
    }

    public static void clearTable() {
        try {
            Connection conn = DB.mycon();
            PreparedStatement pst = conn.prepareStatement("TRUNCATE TABLE admin_his");
            pst.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
