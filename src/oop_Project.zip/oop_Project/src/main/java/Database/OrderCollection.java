/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Database;

import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author TarJ
 */
public class OrderCollection implements Serializable{
    
    public static ArrayList<Order> ordersList = new ArrayList<>();
    
    public ArrayList<Order> getOrdersList() {
        return ordersList;
    }
    
    public void addOrdersList(Order order) {
        OrderCollection.ordersList.add(order);
    }
    
    public void dequeueList() {
        OrderCollection.ordersList.remove(0);
    }
    
    public static int getSize() {
        return OrderCollection.ordersList.size();
    }
    
    public String toString() {
        return "OrderCol OBJ";
    }
}
