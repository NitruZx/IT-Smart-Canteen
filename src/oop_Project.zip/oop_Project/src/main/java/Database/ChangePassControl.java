package Database;

import ClientPage.ClientController;
import LoginPage.SignPageController;
import LoginPage.SignUpPageModel;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ChangePassControl implements ActionListener {
    private ChangePass changePass;

    public ChangePassControl() {
        changePass = new ChangePass();
        changePass.setVisible(true);

        changePass.button1.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == changePass.button1) {
            if (changePass.emailField.getText().isEmpty() || String.valueOf(changePass.passField1.getPassword()).isEmpty() || String.valueOf(changePass.passField2.getPassword()).isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please insert all field.", "", JOptionPane.ERROR_MESSAGE);
                return;
            } else if (String.valueOf(changePass.passField2.getPassword()).length() < 6) {
                JOptionPane.showMessageDialog(null, "Please insert at-least 6 character.", "", JOptionPane.ERROR_MESSAGE);
                return;
            }
            SwingWorker worker = new SwingWorker() {
                @Override
                protected Object doInBackground() throws Exception {
                    System.out.println("Loading..");
                    String oldPassHash = DB.getHash(String.valueOf(changePass.passField1.getPassword()));
                    String sql = "SELECT * FROM users WHERE Name='"+ClientController.name+"' AND Email='"+changePass.emailField.getText()+"' AND Password='"+oldPassHash+"' LIMIT 1";
                    String updateSQL = "";
                    SignUpPageModel.passChange(sql, updateSQL, String.valueOf(changePass.passField2.getPassword()));
                    System.out.println(ClientController.name);
                    return null;
                }

                @Override
                protected void done() {
                    System.out.println("Finish!");
                }
            };
            worker.execute();
        }
    }
}
