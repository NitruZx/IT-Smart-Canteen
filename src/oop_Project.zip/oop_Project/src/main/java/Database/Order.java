/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Database;

import DataCall2.MenuKeeping2;
import java.io.Serializable;
import java.sql.Timestamp;

/**
 *
 * @author TarJ
 */
public class Order implements Serializable{
    
    private int queue;
    private Timestamp time;
    private String name;
    private MenuKeeping2 menu;

    public Order() {
        this(0, null, null, "");
    }
    
    public Order(int queue, Timestamp time, MenuKeeping2 menu, String name) {
        this.queue = queue;
        this.time = time;
        this.menu = menu;
        this.name = name;
    }

    public int getQueue() {
        return queue;
    }

    public void setQueue(int queue) {
        this.queue = queue;
    }

    public Timestamp getTime() {
        return time;
    }

    public void setTime(Timestamp time) {
        this.time = time;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public MenuKeeping2 getMenu() {
        return menu;
    }

    public void setMenu(MenuKeeping2 menu) {
        this.menu = menu;
    }

   
}
