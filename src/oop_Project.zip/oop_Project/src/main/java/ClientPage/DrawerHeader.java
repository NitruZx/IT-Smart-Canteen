package ClientPage;

import javax.swing.*;
import com.cell.Button;
import net.miginfocom.layout.Grid;

import javax.swing.border.EmptyBorder;
import java.awt.*;

public class DrawerHeader extends JPanel {

    public Button changeBtn;
    private JPanel btnPanel;
    public DrawerHeader(String name) {
        this.setLayout(new GridLayout(2, 1));
        this.setBackground(new Color(240, 136, 84));

        btnPanel = new JPanel();
        btnPanel.setOpaque(false);

        changeBtn = new Button();
        changeBtn.setText("change password");
        changeBtn.setBackground(new Color(255, 243, 249));
        changeBtn.setShadowColor(new Color(64, 64, 64));
        btnPanel.add(changeBtn);
        btnPanel.setBorder(new EmptyBorder(0, 20, 10, 20));

        JLabel nameText = new JLabel(name, SwingConstants.CENTER);
        nameText.setForeground(Color.WHITE);
        nameText.setFont(new Font("Biome", Font.BOLD, 24));
        nameText.setBorder(new EmptyBorder(20, 0, 0, 0));

        this.add(nameText);
        this.add(btnPanel);
        this.setVisible(true);
    }

}
