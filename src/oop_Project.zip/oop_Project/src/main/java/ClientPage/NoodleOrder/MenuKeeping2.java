package DataCall2;

import Main.Bill;
import java.io.Serializable;
import java.sql.Timestamp;
import java.util.ArrayList;

public class MenuKeeping2 implements Serializable {

    public String menuName, LineMenu, ind, egg, comnent;
    public boolean option;
    public int order;
    public int money;
//    private String[] text = new String[3];

    public MenuKeeping2() {
        this("", "", "", "", false);
    }

    public MenuKeeping2(String TypeMenu, String LineMenu, String ind, String egg, boolean option) {
        this.menuName = TypeMenu;
        this.LineMenu = LineMenu;
        this.ind = ind;
        this.egg = egg;
        this.option = false;
    }

    public MenuKeeping2(String TypeMenu, String LineMenu, String ind) {
        this(TypeMenu, LineMenu, ind, "", false);
    }

    public MenuKeeping2(String TypeMenu, String LineMenu, String ind, String egg) {
        this(TypeMenu, LineMenu, ind, egg, false);
    }

    public MenuKeeping2(String TypeMenu, String LineMenu, String ind, boolean option) {
        this(TypeMenu, LineMenu, ind, "", true);
    }

    public int getMoney() {
        return money;
    }

    public void setMoney(int money) {
        this.money = money;
    }

    public String getTypeMenu() {
        if (this.LineMenu.isEmpty()) {
            return menuName+":"+this.ind;
        }
        return this.LineMenu+ ":"+this.menuName;
    }

    public String getLineMenu() {
        return LineMenu;
    }

    public String getInd() {
        return ind;
    }

    public String getEgg() {
        return egg;
    }

    public String getComnent() {
        return comnent;
    }

    public boolean isOption() {
        return option;
    }

    public int getOrder() {
        return order;
    }

    public void setTypeMenu(String TypeMenu) {
        this.menuName = TypeMenu;
    }

    public void setLineMenu(String LineMenu) {
        this.LineMenu = LineMenu;
    }

    public void setInd(String ind) {
        this.ind = ind;
    }

    public void setInd(ArrayList<String> indList) {
        this.ind = indList.toString();
    }

    public void setEgg(String egg) {
        this.egg = egg;
    }

    public void setComnent(String comnent) {
        this.comnent = comnent;
    }

    public void setOption(boolean b) {
        this.option = b;
    }

    public void setOrder(int order) {
        this.order = order;
    }

    public String[] billText(String name, String line, String ind, String eggString, String timestamp, int order) {
        String[] text = new String[6];
        if (!line.isEmpty()) {
            text[0] = line + " : " + name;

        } else {
            text[0] = name;

        }
        text[1] = ind;
        text[2] = eggString;
        text[3] = timestamp;
        text[4] = this.money + "";
        text[5] = order+"";
        return text;
    }

//    public String[] getText() {
//        return text;
//    }
}
