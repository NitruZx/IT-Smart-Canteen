/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ClientPage;

import Database.ChangePass;
import Database.ChangePassControl;
import Database.Order;
import Database.OrderCollection;
import Interface.updateInfo;
import Main.Bill;
import Queuefunc.QueueTable;
import com.cell.TableActionEvent;
import com.formdev.flatlaf.themes.FlatMacLightLaf;
import java.awt.Color;
import java.awt.Container;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.util.ArrayList;
import javax.swing.JComponent;
import javax.swing.SwingWorker;
import javax.swing.UIManager;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author TarJ
 */
public class ClientController implements ActionListener {

    public static ClientMain clientMain;
    public static JComponent oldGlass;
    public ClientModel clientModel;
    public static boolean isOpen;
    public static OrderCollection orderCol;
    public static String name;
//    public static ArrayList<String[]> billList;

    public ClientController() {
        this("Tester");
    }

    public ClientController(String name) {
        clientMain = new ClientMain(name);
        clientModel = new ClientModel();
        ClientController.name = name;
        loadHistory();
        oldGlass = (JComponent) clientMain.getGlassPane();
        clientModel.showMenu();

        clientMain.order.addActionListener(this);
        clientMain.menu.addActionListener(this);
        clientMain.refreshBtn.addActionListener(this);
        clientMain.userHeader.changeBtn.addActionListener(this);
    }

    public static void glassPane(boolean isShow) {
        JComponent oldGlass = (JComponent) clientMain.getGlassPane();
        clientMain.setGlassPane(new JComponent() {
            @Override
            protected void paintComponent(Graphics g) {
                g.setColor(new Color(0, 0, 0, 150));
                g.fillRect(0, 0, getWidth(), getHeight());
            }
        });
        Container glassPane = (Container) clientMain.getGlassPane();
        if (isShow) {
            glassPane.setVisible(true);
        } else {
            glassPane.setVisible(false);
        }
        glassPane.addMouseListener(new MouseAdapter() {
        });

    }

    private void loadHistory() {
        SwingWorker worker = new SwingWorker() {
            @Override
            protected Object doInBackground() throws Exception {
                recentPageUpdate();
                return null;
            }
        };
        worker.execute();
    }

    public static void showGlassPane(boolean isShow) {
        if (isShow) {
            glassPane(true);
        } else {
            glassPane(false);
            clientMain.setGlassPane(oldGlass);
        }
    }

    public static void orderBtnState() {
        if (isOpen) {
            clientMain.order.setEnabled(true);
            clientMain.order.setText("Order");
            clientMain.order.setForeground(Color.WHITE);
            clientMain.order.setBackground(new Color(184, 59, 94));
        } else {
            clientMain.order.setEnabled(false);
            clientMain.order.setText("Closed");
            clientMain.order.setBackground(new Color(236, 231, 232));
        }
    }

    public static void recentPageUpdate() {
        TableActionEvent event = new TableActionEvent() {
            @Override
            public void onDelete(int row) {
            }

            @Override
            public void onView(int row) {
                String[] text = ClientModel.ClientbillList.get((ClientModel.ClientbillList.size() - 1) - row);
                Bill bill = new Bill(text);
            }
        };
        SwingWorker worker = new SwingWorker() {
            @Override
            protected Object doInBackground() throws Exception {
                ArrayList<Order> list = updateInfo.menuList(" SELECT * FROM admin_his WHERE name IN ('" + ClientController.name + "')");
                QueueTable queueTable = new QueueTable();
                DefaultTableModel model = new DefaultTableModel(null, new String[]{"Time", "Menu", "Price", ""});
                Object[] row = new Object[4];
                for (int i = list.size() - 1; i >= 0; i--) {
                    row[0] = list.get(i).getTime();
                    row[1] = list.get(i).getMenu().getTypeMenu();
                    row[2] = list.get(i).getMenu().getMoney();
                    model.addRow(row);
                }
                clientMain.recentPage.table.setModel(model);
                updateInfo.tableEvent(clientMain.recentPage.table, 3, event);
                return null;
            }
        };
        worker.execute();
    }

    public static void main(String[] args) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            UIManager.setLookAndFeel(new FlatMacLightLaf());
        } catch (Exception e) {
            e.printStackTrace();
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ClientController();
            }
        });
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == clientMain.menu) {
            if (clientMain.drawer.isShow()) {
                clientMain.drawer.hide();
            } else {
                clientMain.drawer.show();
            }
        } else if (e.getSource() == clientMain.order) {
            if (!OrderPage.isOpen) {
                new OrderPage().setVisible(true);
            }
        } else if (e.getSource() == clientMain.refreshBtn) {
            clientModel.showMenu();
            orderBtnState();
            recentPageUpdate();
        } else if (e.getSource() == clientMain.userHeader.changeBtn) {
            System.out.println("Click");
            new ChangePassControl();
        }
    }

}
