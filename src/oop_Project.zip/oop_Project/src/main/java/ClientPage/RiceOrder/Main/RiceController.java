package Main;

import ClientPage.ClientController;
import static ClientPage.ClientController.showGlassPane;
import ClientPage.ClientMain;
import ClientPage.ClientModel;
import ClientPage.OrderPage;
import DataCall.MenuKeeping;
import DataCall2.MenuKeeping2;
import Interface.updateInfo;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.SwingWorker;

public class RiceController implements ActionListener {

    public MenuKeeping2 menuKeeping;
    private CusRice cusRice;
//    public CallingMenu callingMenu = new CallingMenu();

    public RiceController() {
        cusRice = new CusRice();
        cusRice.book.addActionListener(this);
//        cusRice.bk.addActionListener(this);
//        cusRice.ad.addActionListener(this);
        for (JRadioButton meatBox : cusRice.meatBoxes) {
            meatBox.addActionListener(this);
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == cusRice.book) {
            menuKeeping = new MenuKeeping2();
            for (int i = 0; i < cusRice.meatBoxes.length; i++) {
                if (cusRice.meatBoxes[i].isSelected()) {
//                System.out.println(cusRice.meatBoxes[i].getText());
                    menuKeeping.setInd((String) cusRice.meatBoxes[i].getText());
                    menuKeeping.setMoney(menuKeeping.getMoney() + 40);
                }
            }
            menuKeeping.setTypeMenu(cusRice.menu.getText());
//            System.out.println(cusRice.menu.getText());
            if (cusRice.omelette.isSelected()) {
//                System.out.println(cusRice.omelette.getText());
                menuKeeping.setEgg((String) cusRice.omelette.getText());
                menuKeeping.setMoney(menuKeeping.getMoney() + 10);
            } else if (cusRice.friedegg.isSelected()) {
//                System.out.println(cusRice.friedegg.getText());
                menuKeeping.setEgg((String) cusRice.friedegg.getText());
                menuKeeping.setMoney(menuKeeping.getMoney() + 10);
            } else if (cusRice.boiledegg.isSelected()) {
//                System.out.println(cusRice.boiledegg.getText());
                menuKeeping.setEgg((String) cusRice.boiledegg.getText());
                menuKeeping.setMoney(menuKeeping.getMoney() + 10);
            }
            if (cusRice.spe.isSelected()) {
//                System.out.println("true");
                menuKeeping.setMoney(menuKeeping.getMoney() + 10);
                menuKeeping.setOption(Boolean.TRUE);
            } else if (cusRice.normal.isSelected()) {
//                System.out.println("false");
                menuKeeping.setMoney(menuKeeping.getMoney());
                menuKeeping.setOption(Boolean.FALSE);
            }
            menuKeeping.setComnent(cusRice.comment.getText());
            System.out.print(menuKeeping.getTypeMenu() + " : ");
            System.out.println(menuKeeping.getInd());
            System.out.println(menuKeeping.getEgg());
            System.out.println(menuKeeping.getComnent());
            System.out.println(menuKeeping.getMoney());
            SwingWorker worker = new SwingWorker() {

                @Override
                protected Object doInBackground() throws Exception {
                    showGlassPane(true);
                    ClientMain.loadingDialog.setVisible(true);
                    updateInfo.book(0, menuKeeping, "Tester2");
                    return null;
                }

                @Override
                protected void done() {
//                    ClientController.recentPageUpdate();
                    ClientModel.showMenu();
                    showGlassPane(false);
                    ClientMain.loadingDialog.dispose();
                }
            };
            if (emptyCheck()) {
                worker.execute();
            }

//        } else if (e.getSource() == cusRice.bk) {
//            callingMenu.readMenu();
//        } else if ()
        }

    }

        public boolean emptyCheck() {
        if (!(menuKeeping.getTypeMenu().isEmpty() || menuKeeping.getInd().isEmpty() || menuKeeping.getEgg().isEmpty())) {
            return true;
        } else {
            JOptionPane.showMessageDialog(null, "Please enter all field", "Order", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }
    
    public static void main(String[] args) {
        new RiceController();
    }

    public JPanel getMainPanel() {
        return cusRice.getMainPn();
    }
}
