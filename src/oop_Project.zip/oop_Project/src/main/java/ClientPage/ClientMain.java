package ClientPage;


import AdminPage.*;
import LoginPage.Main;
import com.cell.PanelGradiant;
import com.cell.Clock;
import com.cell.loadingDialog.DequeueDialog;
import com.cell.loadingDialog.LoadingDialog;
import com.formdev.flatlaf.themes.FlatMacLightLaf;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Image;
import javaswingdev.drawer.Drawer;
import javaswingdev.drawer.DrawerController;
import javaswingdev.drawer.DrawerItem;
import javaswingdev.drawer.EventDrawer;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.UIManager;
import com.cell.Button;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
/**
 *
 * @author TarJ
 */
public class ClientMain extends javax.swing.JFrame {

    public DrawerController drawer;
    private DrawerItem managebtn, queueBtn, logoutBtn;
    private CardLayout cardLayout;
    private JPanel btnPanel, timePanel;
    public JButton menu;
    private Thread t;
    public RecentOrderPage recentPage;
    public static LoadingDialog loadingDialog;
    public static JComponent ogGlassPane;
    private String name;
    public DrawerHeader userHeader;

    public ClientMain() {
        this("");
    }

    /**
     * Creates new form AdminMain
     */
    public ClientMain(String username) {
        initComponents();
        this.setName(username);
        loadingDialog = new LoadingDialog(this);
        clock.setForeground(Color.WHITE);
        t = new Thread(clock);
        t.start();
        
        btnPanel = new JPanel();
        btnPanel.setOpaque(false);
        btnPanel.setBounds(0, 0, 100, 100);
        
        order.setBackground(new Color(184, 59, 94));
        order.setForeground(Color.WHITE);
        order.setShadowColor(new Color(69, 66, 86));
        
        ImageIcon icon = new ImageIcon("src/main/java/Icon/menu3.png");
        Image img = icon.getImage();
        Image newimg = img.getScaledInstance(50, 50, Image.SCALE_SMOOTH);
        ImageIcon menuIcon = new ImageIcon(newimg);
        
        menu = new JButton(menuIcon);
        menu.setBounds(10, 20, 95, 60);
        menu.setBorderPainted(false);
        menu.setContentAreaFilled(false);
        menu.setFocusPainted(false);
        menu.setForeground(Color.WHITE);
        
        btnPanel.setLayout(null);
        btnPanel.add(menu);
        btnPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        recentPage = new RecentOrderPage();
        card2.setLayout(new BorderLayout());
        card2.add(recentPage, BorderLayout.CENTER);
        
        managebtn = new DrawerItem("Home");
        queueBtn = new DrawerItem("History");
        logoutBtn = new DrawerItem("Log Out");
        cardLayout = (CardLayout) cardPanel.getLayout();
        cardLayout.show(cardPanel, "card1");
        card1.setOpaque(false);
        
        panelGradiant.addColor(new ModelColor(new Color(109, 93, 110), 0f), new ModelColor(new Color(79, 69, 87), 0.2f), 
                new ModelColor(new Color(79, 69, 87), 0.7f), new ModelColor(new Color(57, 54, 70), 1f));

        userHeader = new DrawerHeader(username);
        drawer = Drawer.newDrawer(this)
                .duration(300)
                .drawerWidth(200)
                .header(userHeader)
                .space(10)
                //                .separator(2, Color.WHITE)
                .enableScroll(true)
                .addChild(managebtn.build())
                .addChild(queueBtn.build())
                .addFooter(logoutBtn.build())
                .event(new EventDrawer() {
            @Override
            public void selected(int i, DrawerItem di) {
                if (i == 0) {
                    cardLayout.show(cardPanel, "card1");
                } else if (i == 1) {
                    cardLayout.show(cardPanel, "card2");
                } else if (i == 2) {
                    int option = JOptionPane.showOptionDialog(null, "Are you sure to logout?", "LogOut", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, null, 0);
                    if (option == 0) {
                        new Main();
                        dispose();
                    } else {
                        drawer.hide();
                    }
                }
            }
                })
                .build();

        
        
        panelGradiant.add(btnPanel);
        this.add(panelGradiant, BorderLayout.NORTH);
        this.setExtendedState(this.MAXIMIZED_BOTH);
        this.setVisible(true);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panelGradiant = new com.cell.PanelGradiant();
        clock = new com.cell.Clock();
        cardPanel = new javax.swing.JPanel();
        card1 = new javax.swing.JPanel();
        topPanel = new javax.swing.JPanel();
        recentQ = new javax.swing.JLabel();
        order = new Button();
        centerPanel = new javax.swing.JPanel();
        roundedPanel1 = new com.test.RoundedPanel();
        queueTable = new Queuefunc.QueueTable();
        refreshBtn = new javax.swing.JButton();
        card2 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));
        setMinimumSize(new java.awt.Dimension(1280, 720));

        clock.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        clock.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N

        javax.swing.GroupLayout panelGradiantLayout = new javax.swing.GroupLayout(panelGradiant);
        panelGradiant.setLayout(panelGradiantLayout);
        panelGradiantLayout.setHorizontalGroup(
            panelGradiantLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelGradiantLayout.createSequentialGroup()
                .addContainerGap(1759, Short.MAX_VALUE)
                .addComponent(clock, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(53, 53, 53))
        );
        panelGradiantLayout.setVerticalGroup(
            panelGradiantLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelGradiantLayout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(clock, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(33, Short.MAX_VALUE))
        );

        getContentPane().add(panelGradiant, java.awt.BorderLayout.PAGE_START);

        cardPanel.setLayout(new java.awt.CardLayout());

        card1.setLayout(new java.awt.BorderLayout());

        topPanel.setBackground(new java.awt.Color(255, 255, 255));
        topPanel.setPreferredSize(new java.awt.Dimension(0, 100));

        recentQ.setBackground(new java.awt.Color(0, 0, 0));
        recentQ.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        recentQ.setText("#Queue");

        order.setText("Order");

        javax.swing.GroupLayout topPanelLayout = new javax.swing.GroupLayout(topPanel);
        topPanel.setLayout(topPanelLayout);
        topPanelLayout.setHorizontalGroup(
            topPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(topPanelLayout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(recentQ)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 1662, Short.MAX_VALUE)
                .addComponent(order, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(38, 38, 38))
        );
        topPanelLayout.setVerticalGroup(
            topPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(topPanelLayout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(order, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(21, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, topPanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(recentQ)
                .addGap(31, 31, 31))
        );

        card1.add(topPanel, java.awt.BorderLayout.NORTH);

        centerPanel.setBackground(new java.awt.Color(249, 247, 247));

        roundedPanel1.setBackground(new java.awt.Color(238, 238, 238));

        queueTable.setFont(new java.awt.Font("TH SarabunPSK", 0, 12)); // NOI18N

        refreshBtn.setText("Refresh");
        refreshBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                refreshBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout roundedPanel1Layout = new javax.swing.GroupLayout(roundedPanel1);
        roundedPanel1.setLayout(roundedPanel1Layout);
        roundedPanel1Layout.setHorizontalGroup(
            roundedPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundedPanel1Layout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addGroup(roundedPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(queueTable, javax.swing.GroupLayout.PREFERRED_SIZE, 1588, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(refreshBtn))
                .addContainerGap(40, Short.MAX_VALUE))
        );
        roundedPanel1Layout.setVerticalGroup(
            roundedPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundedPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(refreshBtn)
                .addGap(3, 3, 3)
                .addComponent(queueTable, javax.swing.GroupLayout.PREFERRED_SIZE, 523, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(41, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout centerPanelLayout = new javax.swing.GroupLayout(centerPanel);
        centerPanel.setLayout(centerPanelLayout);
        centerPanelLayout.setHorizontalGroup(
            centerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(centerPanelLayout.createSequentialGroup()
                .addGap(126, 126, 126)
                .addComponent(roundedPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(126, 126, 126))
        );
        centerPanelLayout.setVerticalGroup(
            centerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(centerPanelLayout.createSequentialGroup()
                .addGap(97, 97, 97)
                .addComponent(roundedPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(187, Short.MAX_VALUE))
        );

        card1.add(centerPanel, java.awt.BorderLayout.CENTER);

        cardPanel.add(card1, "card1");

        card2.setBackground(new java.awt.Color(204, 255, 204));

        javax.swing.GroupLayout card2Layout = new javax.swing.GroupLayout(card2);
        card2.setLayout(card2Layout);
        card2Layout.setHorizontalGroup(
            card2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1920, Short.MAX_VALUE)
        );
        card2Layout.setVerticalGroup(
            card2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 980, Short.MAX_VALUE)
        );

        cardPanel.add(card2, "card2");

        getContentPane().add(cardPanel, java.awt.BorderLayout.CENTER);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void refreshBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_refreshBtnActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_refreshBtnActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            UIManager.setLookAndFeel(new FlatMacLightLaf());
        } catch (Exception e) {
            e.printStackTrace();
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ClientMain().setVisible(true);
            }
        });
    }

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel card1;
    private javax.swing.JPanel card2;
    private javax.swing.JPanel cardPanel;
    private javax.swing.JPanel centerPanel;
    private com.cell.Clock clock;
    public Button order;
    private com.cell.PanelGradiant panelGradiant;
    public static Queuefunc.QueueTable queueTable;
    private javax.swing.JLabel recentQ;
    public javax.swing.JButton refreshBtn;
    private com.test.RoundedPanel roundedPanel1;
    private javax.swing.JPanel topPanel;
    // End of variables declaration//GEN-END:variables
}
