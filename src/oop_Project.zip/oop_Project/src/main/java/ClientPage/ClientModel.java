/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ClientPage;

import AdminPage.AdminModel;
import Database.Order;
import Interface.updateInfo;
import java.util.ArrayList;
import javax.swing.SwingWorker;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author TarJ
 */
public class ClientModel {

    public static ArrayList<String[]> ClientbillList;
//    public static ArrayList<Order> menuList(String sql) {
//
//        ArrayList<Order> menusList = new ArrayList<>();
//        try {
//            Connection con = DB.mycon();
//            PreparedStatement pst = con.prepareStatement(sql);
//            ResultSet rs = pst.executeQuery();
//
//            Order menu;
//            while (rs.next()) {
//                Timestamp time = rs.getObject("time", Timestamp.class);
//                byte[] st = (byte[]) rs.getObject("menu");
//                int queue = rs.getInt("id");
//                ByteArrayInputStream baip = new ByteArrayInputStream(st);
//                ObjectInputStream ois = new ObjectInputStream(baip);
//                MenuKeeping2 menuKeep = (MenuKeeping2) ois.readObject();
//                
//                String[] bill = menuKeep.billText(menuKeep.getTypeMenu(), menuKeep.getLineMenu(), menuKeep.getInd(), menuKeep.getEgg(), time.toString(), queue);
//                ClientController.billList.add(bill);
//                
//                menu = new Order(queue, time, menuKeep, rs.getString("name"));
//
//                menusList.add(menu);
//            }
//            pst.close();
//            rs.close();
//            con.close();
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return menusList;
//    }

    public static void showMenu() {
        SwingWorker worker = new SwingWorker() {
            @Override
            protected Object doInBackground() throws Exception {
                ClientController.showGlassPane(true);
                ClientMain.loadingDialog.setVisible(true);
                ArrayList<Order> list = updateInfo.menuList(" SELECT * FROM queue");
//        DefaultTableModel model = (DefaultTableModel) ClientMain.queueTable.table.getModel();
                DefaultTableModel newModel = new DefaultTableModel(null, new String[]{"Queue", "Time", "Menu", "Name"});
                Object[] row = new Object[4];
                for (int i = 0; i < list.size(); i++) {
                    row[0] = String.format("%03d", list.get(i).getQueue());
                    row[1] = list.get(i).getTime().toString();
                    row[2] = list.get(i).getMenu().getTypeMenu();
                    row[3] = list.get(i).getName();
                    newModel.addRow(row);
                }
                ClientMain.queueTable.table.setModel(newModel);
                ClientController.isOpen = AdminModel.stateCheck();
                ClientController.orderBtnState();
                return null;
            }

            @Override
            protected void done() {
                ClientController.showGlassPane(false);
                ClientMain.loadingDialog.dispose();
            }

        };
        worker.execute();
    }
}
