package com.cell.loadingDialog;

import javax.swing.*;

public class LoginLoad extends JDialog {

    public LoginLoad(JFrame frame) {
        super(frame, "Loading, Please wait.");
        ImageIcon icon = new ImageIcon("src/main/java/Icon/loginLoadS.gif");
        JLabel pic = new JLabel(icon);

        this.add(pic);

        this.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        this.setResizable(false);
        this.pack();
        this.setLocationRelativeTo(null);
    }

}
