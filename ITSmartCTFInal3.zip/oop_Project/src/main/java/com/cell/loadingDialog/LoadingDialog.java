/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.cell.loadingDialog;

import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;

/**
 *
 * @author TarJ
 */
public class LoadingDialog extends JDialog {

    public LoadingDialog(JFrame frame) {
        super(frame, "Loading, Please wait.");
        ImageIcon icon = new ImageIcon("src/main/java/Icon/cooking2L.gif");
        JLabel pic = new JLabel(icon);

        this.add(pic);

        this.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        this.setResizable(false);
        this.pack();
        this.setLocationRelativeTo(null);
    }

}
