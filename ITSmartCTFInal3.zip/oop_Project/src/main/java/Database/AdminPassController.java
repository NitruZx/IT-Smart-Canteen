package Database;

import AdminPage.AdminModel;
import AdminPage.AdminPageController;
import ClientPage.ClientController;
import ClientPage.ClientModel;
import LoginPage.SignUpPageModel;

import javax.swing.*;
import java.awt.event.*;

public class AdminPassController extends UserManage implements ActionListener, WindowListener {
    private final PassChange passChange;
    private final AdminModel adminModel;
    public AdminPassController() {
        passChange = new PassChange();
        adminModel = new AdminModel();

        passChange.verifyBtn.addActionListener(this);
        passChange.changeBtn.addActionListener(this);
        passChange.getFrame().addWindowListener(this);
        passChange.getFrame().setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == passChange.verifyBtn) {
            passChange.glassPane.setVisible(true);
            String sql = "SELECT * FROM admin WHERE Name=? AND Email=? LIMIT 1";
            if (passChange.emailField.getText().isEmpty() || String.valueOf(passChange.oldPassField.getPassword()).isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please insert all field.", "Change Password", JOptionPane.ERROR_MESSAGE);
            } else if (verfifyPass("nargo", passChange.emailField.getText(), String.valueOf(passChange.oldPassField.getPassword()), sql)) {
                passChange.cardLayout.show(passChange.cardPanel, "set");
            }
            passChange.glassPane.setVisible(false);
            passChange.cardLayout.show(passChange.cardPanel, "set");
        } else if (e.getSource() == passChange.changeBtn) {
            SwingWorker worker = new SwingWorker() {
                @Override
                protected Object doInBackground() throws Exception {
                    passChange.glassPane.setVisible(true);
                    updateUserPassword("admin", String.valueOf(passChange.oldPassField.getPassword()), String.valueOf(passChange.newPassField.getPassword()), String.valueOf(passChange.conNewPass.getPassword()), "nargo");
                    return null;
                }

                @Override
                protected void done() {
                    passChange.glassPane.setVisible(false);
                }
            };
            worker.execute();
        }
    }

    @Override
    public void windowActivated(WindowEvent e) {
        AdminPageController.adminMain.setEnabled(false);
        AdminPageController.showGlassPane(true);
    }

    @Override
    public void windowDeactivated(WindowEvent e) {

    }

    @Override
    public void windowOpened(WindowEvent e) {
    }

    @Override
    public void windowClosing(WindowEvent e) {
        AdminPageController.adminMain.setEnabled(true);
        AdminPageController.showGlassPane(false);
    }

    @Override
    public void windowClosed(WindowEvent e) {
    }

    @Override
    public void windowIconified(WindowEvent e) {
    }

    @Override
    public void windowDeiconified(WindowEvent e) {
    }
}
