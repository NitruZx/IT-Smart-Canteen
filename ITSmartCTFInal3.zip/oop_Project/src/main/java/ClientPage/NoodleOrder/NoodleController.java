package ClientPage.NoodleOrder;

import ClientPage.ClientController;
import static ClientPage.ClientController.showGlassPane;
import ClientPage.ClientMain;
import ClientPage.ClientModel;
import ClientPage.EmptyCheck;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import javax.swing.JCheckBox;
import javax.swing.JPanel;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.SwingWorker;

public class NoodleController extends ClientModel implements ActionListener, ItemListener, EmptyCheck {

    public MenuKeep menuKeeping2;
    private Cusnoodle cusNoodle;
    private ClientModel clientModel;
    public ArrayList<String> indList = new ArrayList<>();
    int countInd = 0;
    //int countEgg = 0;

    public NoodleController() {
        cusNoodle = new Cusnoodle();
        clientModel = new ClientModel();
        cusNoodle.book.addActionListener(this);
        cusNoodle.spc1.addActionListener(this);
        for (JCheckBox Indbox : cusNoodle.Ind) {
            Indbox.addActionListener(this);
            Indbox.addItemListener(this);
        }
        for (JRadioButton eggBox : cusNoodle.eggBoxs) {
            eggBox.addActionListener(this);
            eggBox.addItemListener(this);
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource().equals(cusNoodle.book)) {
            menuKeeping2 = new MenuKeep();
            System.out.println(cusNoodle.manu.getItemAt(cusNoodle.manu.getSelectedIndex()));
            menuKeeping2.setTypeMenu((String) cusNoodle.manu.getItemAt(cusNoodle.manu.getSelectedIndex()));
//            callingMenu2.writeMenu(menuKeeping2);
            if (cusNoodle.line1.isSelected()) {
                System.out.println(cusNoodle.line1.getText());
                menuKeeping2.setLineMenu((String) cusNoodle.line1.getText());
                //callingMenu2.writeMenu(menuKeeping2);
            }
            if (cusNoodle.line2.isSelected()) {
                System.out.println(cusNoodle.line2.getText());
                menuKeeping2.setLineMenu((String) cusNoodle.line2.getText());
            }
            if (cusNoodle.line3.isSelected()) {
                System.out.println(cusNoodle.line3.getText());
                menuKeeping2.setLineMenu((String) cusNoodle.line3.getText());
            }
            if (cusNoodle.line4.isSelected()) {
                System.out.println(cusNoodle.line4.getText());
                menuKeeping2.setLineMenu((String) cusNoodle.line4.getText());
            }
            if (cusNoodle.line5.isSelected()) {
                System.out.println(cusNoodle.line5.getText());
                menuKeeping2.setLineMenu((String) cusNoodle.line5.getText());
            }
            for (JCheckBox Indbox : cusNoodle.Ind) {
                if (Indbox.isSelected()) {
                    System.out.print(Indbox.getText() + "");
                    System.out.println("");
                    indList.add(Indbox.getText());
                }
                menuKeeping2.setInd(indList);
            }
            for (JRadioButton eggBox : cusNoodle.eggBoxs) {
                if (cusNoodle.eggBoxs[3].isSelected()) {
                    //countEgg += 0;
                    menuKeeping2.setEgg("ไม่ใส่ไข่");
                }
                else if (eggBox.isSelected()) {
                    System.out.println(eggBox.getText());
                    menuKeeping2.setEgg((String) eggBox.getText());
                }
 //           menuKeeping2.setMoney(menuKeeping2.getMoney() + (countEgg) * 10);
            }
            if (cusNoodle.spc1.isSelected()) {
                menuKeeping2.setOption(true);
                System.out.println("พิเศษ");
            }
            if (cusNoodle.spc2.isSelected()) {
                menuKeeping2.setOption(false);
                System.out.println("พิเศษ ที่ไหนหละ ");
            }
            menuKeeping2.setComnent(cusNoodle.comment.getText());
//            callingMenu2.writeMenu(menuKeeping2);
            MoneyCal();
            System.out.println(menuKeeping2.getMoney());

            SwingWorker worker = new SwingWorker() {

                @Override
                protected Object doInBackground() throws Exception {
                    showGlassPane(true);
                    ClientMain.loadingDialog.setVisible(true);
                    book(menuKeeping2, ClientController.name);
                    return null;
                }

                @Override
                protected void done() {
                    showMenu();
                    showGlassPane(false);
                    ClientMain.loadingDialog.dispose();
                    cusNoodle.eggGroup.clearSelection();
                    cusNoodle.lGroup.clearSelection();
                    cusNoodle.SpcGroup.clearSelection();
                    cusNoodle.comment.setText("");
                    for (JCheckBox box : cusNoodle.Ind) {
                        box.setSelected(false);
                    }
                }
            };
            if (emptyCheck()) {
                worker.execute();
            }
        }
    }

    public boolean emptyCheck() {
        if (!(menuKeeping2.getLineMenu().isEmpty() || menuKeeping2.getTypeMenu().isEmpty() || menuKeeping2.getInd().isEmpty() || menuKeeping2.getEgg().isEmpty())) {
            return true;
        } else {
            JOptionPane.showMessageDialog(null, "Please enter all field", "Order", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }
    
    public static void main(String[] args) {
        new NoodleController();
    }

    @Override
    public void itemStateChanged(ItemEvent e) {
        for (JCheckBox indBox : cusNoodle.Ind) {
            if (e.getSource() == indBox) {
                if (e.getStateChange() == ItemEvent.SELECTED) {
                    countInd++;
                }
                if (e.getStateChange() == ItemEvent.DESELECTED) {
                    countInd--;
                }
            }
        }
//        for (JRadioButton eggBox : cusNoodle.eggBoxs) {
//            if (e.getSource() == eggBox) {
//                if (e.getStateChange() == ItemEvent.SELECTED) {
//                    countEgg++;
//                }
//                if (e.getStateChange() == ItemEvent.DESELECTED) {
//                    countEgg--;
//                }
//            }
//        }
    }

    public void MoneyCal() {
        //menuKeeping2.setMoney(menuKeeping2.getMoney() + (countEgg) * 10);
        if (countInd == 1) {
            menuKeeping2.setMoney(menuKeeping2.getMoney() + 40);
        } else if (countInd > 1) {
            menuKeeping2.setMoney(menuKeeping2.getMoney() + (countInd - 1) * 20 + 40);
        }
        if (menuKeeping2.isOption()) {
            menuKeeping2.setMoney(menuKeeping2.getMoney() + 15);
        }
        if (cusNoodle.eggBoxs[0].isSelected() || cusNoodle.eggBoxs[1].isSelected() || cusNoodle.eggBoxs[2].isSelected()){
             menuKeeping2.setMoney(menuKeeping2.getMoney() + 10);
        }else if (cusNoodle.eggBoxs[3].isSelected()) {
             menuKeeping2.setMoney(menuKeeping2.getMoney() + 0);
        }
    }

    public JPanel getBig() {
        return cusNoodle.getBig();
    }
}
