package ClientPage.RiceOrder.Main;

import static ClientPage.ClientController.showGlassPane;

import ClientPage.ClientController;
import ClientPage.ClientMain;
import ClientPage.ClientModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.SwingWorker;

import ClientPage.EmptyCheck;
import ClientPage.NoodleOrder.MenuKeep;

public class RiceController extends ClientModel implements ActionListener, EmptyCheck {

    public MenuKeep menuKeeping;
    private CusRice cusRice;
//    public CallingMenu callingMenu = new CallingMenu();

    public RiceController() {
        cusRice = new CusRice();
        cusRice.book.addActionListener(this);
//        cusRice.bk.addActionListener(this);
//        cusRice.ad.addActionListener(this);
        for (JRadioButton meatBox : cusRice.meatBoxes) {
            meatBox.addActionListener(this);
        }
        cusRice.clearEgg.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == cusRice.book) {
            menuKeeping = new MenuKeep();
            for (int i = 0; i < cusRice.meatBoxes.length; i++) {
                if (cusRice.meatBoxes[i].isSelected()) {
//                System.out.println(cusRice.meatBoxes[i].getText());
                    menuKeeping.setInd((String) cusRice.meatBoxes[i].getText());
                    menuKeeping.setMoney(menuKeeping.getMoney() + 40);
                }
            }
            menuKeeping.setTypeMenu(cusRice.menu.getText());
//            System.out.println(cusRice.menu.getText());
            if (cusRice.omelette.isSelected()) {
//                System.out.println(cusRice.omelette.getText());
                menuKeeping.setEgg((String) cusRice.omelette.getText());
                menuKeeping.setMoney(menuKeeping.getMoney() + 10);
            } else if (cusRice.friedegg.isSelected()) {
//                System.out.println(cusRice.friedegg.getText());
                menuKeeping.setEgg((String) cusRice.friedegg.getText());
                menuKeeping.setMoney(menuKeeping.getMoney() + 10);
            } else if (cusRice.boiledegg.isSelected()) {
//                System.out.println(cusRice.boiledegg.getText());
                menuKeeping.setEgg((String) cusRice.boiledegg.getText());
                menuKeeping.setMoney(menuKeeping.getMoney() + 10);
            }
            if (cusRice.spe.isSelected()) {
//                System.out.println("true");
                menuKeeping.setMoney(menuKeeping.getMoney() + 10);
                menuKeeping.setOption(Boolean.TRUE);
            } else if (cusRice.normal.isSelected()) {
//                System.out.println("false");
                menuKeeping.setMoney(menuKeeping.getMoney());
                menuKeeping.setOption(Boolean.FALSE);
            }
            menuKeeping.setComnent(cusRice.comment.getText());
            System.out.print(menuKeeping.getTypeMenu() + " : ");
            System.out.println(menuKeeping.getInd());
            System.out.println(menuKeeping.getEgg());
            System.out.println(menuKeeping.getComnent());
            System.out.println(menuKeeping.getMoney());
            SwingWorker worker = new SwingWorker() {

                @Override
                protected Object doInBackground() throws Exception {
                    showGlassPane(true);
                    ClientMain.loadingDialog.setVisible(true);
                    book(menuKeeping, ClientController.name);
                    return null;
                }

                @Override
                protected void done() {
                    showMenu();
                    showGlassPane(false);
                    ClientMain.loadingDialog.dispose();
                    cusRice.eggGroup.clearSelection();
                    cusRice.meatGroup.clearSelection();
                    cusRice.speGroup.clearSelection();
                    cusRice.menu.setText("");
                    cusRice.comment.setText("");
                }
            };
            if (emptyCheck()) {
                worker.execute();
            }
        } else if (e.getSource() == cusRice.clearEgg) {
            cusRice.eggGroup.clearSelection();
        }
    }
        public boolean emptyCheck() {
        if (!(menuKeeping.getTypeMenu().isEmpty() || menuKeeping.getInd().isEmpty() || menuKeeping.getEgg().isEmpty())) {
            return true;
        } else {
            JOptionPane.showMessageDialog(null, "Please enter all field", "Order", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }
    
    public static void main(String[] args) {
        new RiceController();
    }

    public JPanel getMainPanel() {
        return cusRice.getMainPn();
    }
}
