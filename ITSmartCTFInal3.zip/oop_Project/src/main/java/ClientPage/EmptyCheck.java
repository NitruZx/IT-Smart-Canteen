package ClientPage;

public interface EmptyCheck {

    public boolean emptyCheck();

}
