package AdminPage;

import Database.BillInternalFrame;
import Database.Order;

import javax.swing.*;
import javax.swing.event.InternalFrameEvent;
import javax.swing.event.InternalFrameListener;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

public class HistoryControl extends AdminModel implements ActionListener, MouseListener, InternalFrameListener {
    public HistoryView historyView;
    private TotalFrame totalFrame;
    private BillInternalFrame bill;
    public HistoryControl() {
        historyView = new HistoryView();
        updateHistory();

        historyView.showBill.setState(false);
        historyView.showTotal.setState(false);

        historyView.getHistoryTable().table.addMouseListener(this);
        historyView.searchBtn.addActionListener(this);
        historyView.showBill.addActionListener(this);
        historyView.showTotal.addActionListener(this);
        historyView.showAllBtn.addActionListener(this);
        historyView.clear.addActionListener(this);
        historyView.addInternalFrameListener(this);
    }

    //show เมนูตามระหว่างวันที่ ที่กำหนด
    private void showSearchData() {
        if (historyView.dateChooser1.getDate() == null || historyView.dateChooser2.getDate() == null) {
            updateHistory();
        } else {
            historyView.total = 0;
            SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
            String date1 = df.format(historyView.dateChooser1.getDate());
            String date2 = df.format(historyView.dateChooser2.getDate());
            SwingWorker worker = new SwingWorker() {
                @Override
                protected Object doInBackground() throws Exception {
                    AdminMain.loadingDialog.setVisible(true);
                    ArrayList<Order> list = menuList("select * from admin_his where time between '"+date1+"' and '"+date2+"'", false);
                    DefaultTableModel model = new DefaultTableModel(null, new String[]{"Time", "Menu", "Price", "Name"});
                    historyView.getHistoryTable().table.setModel(model);
                    Object[] row = new Object[4];
                    for (int i = list.size() - 1; i >= 0; i--) {
                        row[0] = list.get(i).getTime();
                        row[1] = list.get(i).getMenu().getTypeMenu();
                        row[2] = list.get(i).getMenu().getMoney();
                        row[3] = list.get(i).getName();
                        model.addRow(row);
                        historyView.total += list.get(i).getMenu().getMoney();
                    }
                    return null;
                }
                @Override
                protected void done() {
                    AdminMain.loadingDialog.dispose();
                }
            };
            worker.execute();
        }

    }

    //update ประวัติของ admin
    public void updateHistory() {
        historyView.total = 0;
        SwingWorker worker = new SwingWorker() {
            @Override
            protected Object doInBackground() throws Exception {
                AdminMain.loadingDialog.setVisible(true);
                ArrayList<Order> list = menuList(" SELECT * FROM admin_his", false);
//                DefaultTableModel model = new DefaultTableModel(null, new String[]{"Time", "Menu", "Price", "Name"});
                setTableModel(historyView.getHistoryTable().table, new String[]{"Time", "Menu", "Price", "Name"});
                DefaultTableModel model = (DefaultTableModel) historyView.getHistoryTable().table.getModel();
                historyView.getHistoryTable().table.setModel(model);
                Object[] row = new Object[4];
                for (int i = list.size() - 1; i >= 0; i--) {
                    row[0] = list.get(i).getTime();
                    row[1] = list.get(i).getMenu().getTypeMenu();
                    row[2] = list.get(i).getMenu().getMoney();
                    row[3] = list.get(i).getName();
                    model.addRow(row);
                    historyView.total += list.get(i).getMenu().getMoney();
                }
                return null;
            }

            @Override
            protected void done() {
                AdminMain.loadingDialog.dispose();
            }

        };
        worker.execute();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == historyView.searchBtn) {
            showSearchData();
        } else if (e.getSource() == historyView.showAllBtn) {
            updateHistory();
            historyView.dateChooser1.setCalendar(null);
            historyView.dateChooser2.setCalendar(null);
        } else if (e.getSource() == historyView.showBill) {
            if (historyView.showBill.isSelected()) {
                String[] text;
                bill = new BillInternalFrame();
                text = new String[8];
                bill.setBillText(text);
                AdminMain.Desktop.add(bill);
            } else {
                bill.dispose();
            }
        } else if (e.getSource() == historyView.showTotal) {
            if (historyView.showTotal.isSelected()) {
                totalFrame = new TotalFrame();
                totalFrame.text.setText("รายรับรวม : "+historyView.total+" บาท");
                AdminMain.Desktop.add(totalFrame);
            } else {
                totalFrame.dispose();
            }
        } else if (e.getSource() == historyView.clear) {
            runSQLQuery("TRUNCATE TABLE admin_his", "History Clear Failed");
        }
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        if (e.getSource() == historyView.getHistoryTable().table) {
            if (!(bill == null)) {
                int indexFix = adminHistoryBill.size() - 1;
                String[] text = adminHistoryBill.get(indexFix - historyView.getHistoryTable().table.getSelectedRow());
                bill.setBillText(text);
            }
        }
    }

    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

    @Override
    public void internalFrameOpened(InternalFrameEvent e) {
         HistoryView.isOpen = true;
    }

    @Override
    public void internalFrameClosing(InternalFrameEvent e) {
        HistoryView.isOpen = false;
        if (!(bill == null)) {
            bill.dispose();
        }
        if (!(totalFrame == null)) {
            totalFrame.dispose();
        }
    }

    @Override
    public void internalFrameClosed(InternalFrameEvent e) {
    }

    @Override
    public void internalFrameIconified(InternalFrameEvent e) {
    }

    @Override
    public void internalFrameDeiconified(InternalFrameEvent e) {
    }

    @Override
    public void internalFrameActivated(InternalFrameEvent e) {
    }

    @Override
    public void internalFrameDeactivated(InternalFrameEvent e) {
    }
}
