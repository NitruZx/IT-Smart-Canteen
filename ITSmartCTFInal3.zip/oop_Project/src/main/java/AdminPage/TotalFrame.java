package AdminPage;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class TotalFrame extends JInternalFrame {

    public JLabel text;

    public TotalFrame() {
        super("Total", false, false, false, false);
        text = new JLabel("Total : ");
        text.setFont(new Font("TH SarabunPSK", Font.BOLD, 22));
        text.setBorder(new EmptyBorder(20, 0, 15, 0));
        add(text);

        setSize(160, 100);
        setDefaultCloseOperation(JInternalFrame.DISPOSE_ON_CLOSE);
        setVisible(true);
    }

}
