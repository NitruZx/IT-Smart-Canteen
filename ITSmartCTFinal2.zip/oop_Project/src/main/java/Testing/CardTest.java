package Testing;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CardTest {
    public JFrame frame;
    private JPanel cardPanel, panel1, panel2;
    private CardLayout cardLayout = new CardLayout();
    private JButton btn1, btn2;

    public CardTest() {
        frame = new JFrame("title");
        cardPanel = new JPanel();
        cardPanel.setLayout(cardLayout);
        panel1 = new JPanel();panel1.setBackground(Color.BLUE);
        panel2 = new JPanel();panel2.setBackground(Color.RED);

        btn1 = new JButton("Turn Red");
        btn2 = new JButton("Turn Blue");
        panel1.add(btn1);panel2.add(btn2);

        cardPanel.add(panel1, "1");
        cardPanel.add(panel2, "2");

        cardLayout.show(cardPanel, "1");
        btn1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cardLayout.show(cardPanel, "2");
            }
        });
        btn2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cardLayout.show(cardPanel, "1");
            }
        });

        frame.add(cardPanel);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        new CardTest();
    }
}
