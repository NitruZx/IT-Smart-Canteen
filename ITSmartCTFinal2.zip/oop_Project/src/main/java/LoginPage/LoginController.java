package LoginPage;

import ClientPage.ClientController;
import Database.UserManage;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class LoginController extends LoginModel implements ActionListener,  MouseListener {
    public LoginGUI loginGUI;
    public Container glasspane;
    public LoginController() {
        loginGUI = new LoginGUI();

        LoginGUI.frame.setGlassPane(new JComponent() {
            @Override
            protected void paintComponent(Graphics g) {
                g.setColor(new Color(0, 0, 0, 150));
                g.fillRect(0, 0, getWidth(), getHeight());
            }
        });
        LoginGUI.frame.getGlassPane().addMouseListener(new MouseAdapter() {
        });
        glasspane = (Container) LoginGUI.frame.getGlassPane();

        //MouseListener
        loginGUI.logBut.addMouseListener(this);
        loginGUI.createBut.addMouseListener(this);

        //ActionListener
        loginGUI.logBut.addActionListener(this);
        loginGUI.createBut.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == loginGUI.logBut) {
            String name = loginGUI.nameField.getText();
            String password = String.valueOf(loginGUI.passField.getPassword());
            if (name.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please fill all field", "Login", JOptionPane.PLAIN_MESSAGE);
                return;
            }
            LoadingPage load = new LoadingPage();
            SwingWorker worker = new SwingWorker() {
                @Override
                protected Object doInBackground() throws Exception {
                    loginGUI.loadingScreen.setVisible(true);
                    glasspane.setVisible(true);
                    if (login(name, password, " SELECT * FROM users WHERE Name=? LIMIT 1")) {
                        loginGUI.getFrame().dispose();
                        ClientController clientControl = new ClientController(name);
                    }
                    return null;
                }

                @Override
                protected void done() {
                    glasspane.setVisible(false);
                    loginGUI.loadingScreen.setVisible(false);
                }
            };
            worker.execute();

        } else if (e.getSource() == loginGUI.createBut) {
            new SignPageController();
            loginGUI.getFrame().dispose();
        }
    }

    @Override
    public void mouseClicked(MouseEvent e) {
    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {
        if (e.getSource() == loginGUI.logBut || e.getSource() == loginGUI.createBut)
            ((JButton)e.getSource()).setBackground(new Color(137, 196, 238));
    }

    @Override
    public void mouseExited(MouseEvent e) {
        if (e.getSource() == loginGUI.logBut || e.getSource() == loginGUI.createBut)
            ((JButton)e.getSource()).setBackground(new Color(255, 255, 255, 0));
    }
}
