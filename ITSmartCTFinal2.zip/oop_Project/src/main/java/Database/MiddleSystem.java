package Database;

import AdminPage.AdminModel;
import ClientPage.ClientModel;
import ClientPage.NoodleOrder.MenuKeep;
import com.cell.TableActionCellEditor;
import com.cell.TableActionCellRender;
import com.cell.TableActionEvent;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.ByteArrayInputStream;
import java.io.ObjectInputStream;
import java.sql.*;
import java.util.ArrayList;

import static AdminPage.AdminModel.adminBillList;
import static AdminPage.AdminModel.adminHistoryBill;

public abstract class MiddleSystem extends DB{

    public abstract void showMenu();
    public abstract void updateHistory();

//    set ปุ่ม detail ให้ JTable
    public static void tableEvent(JTable table, int column, TableActionEvent tableEvent) {

        table.getColumnModel().getColumn(column).setCellRenderer(new TableActionCellRender());
        table.getColumnModel().getColumn(column).setCellEditor(new TableActionCellEditor(tableEvent));
    }

    /*Method จองอาหาร*/
    public static void book(MenuKeep food, String name) {
        JLabel text = new JLabel("ราคาอาหาร : "+food.getMoney()+" บาท ยืนยันการจองหรือไม่");
        text.setFont(new Font("TH SarabunPSK", Font.BOLD, 18));
        int option = JOptionPane.showOptionDialog(null, text, "Confirm", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, null, 0);
        if (option == 0) {
            try {
                Connection con = mycon();
                PreparedStatement pst = con.prepareStatement("INSERT INTO queue (queue, time, menu, name) VALUES (?, ?, ?, ?)", Statement.RETURN_GENERATED_KEYS);
                PreparedStatement pst2 = con.prepareStatement("INSERT INTO admin_his (time, menu, name) VALUES (?, ?, ?)");
                Timestamp timestamp = new java.sql.Timestamp(new java.util.Date().getTime());
                pst.setInt(1, 0);
                pst.setTimestamp(2, timestamp);
                pst.setObject(3, food);
                pst.setString(4, name);
                pst2.setTimestamp(1, timestamp);
                pst2.setObject(2, food);
                pst2.setString(3, name);
                int addedRows = pst.executeUpdate();
                pst2.executeUpdate();
                if (addedRows > 0) {
                    try (ResultSet generatedKey = pst.getGeneratedKeys()){
                        if (generatedKey.next()) {
                            String[] bill = food.billText(food.getTypeMenu(), food.getLineMenu(), food.getInd(), food.getEgg(), timestamp.toString(), generatedKey.getInt(1), food.getExtra(), food.getComnent());
                            BillFrame billFrame = new BillFrame();
                            billFrame.setBillText(bill);
                            JDialog jd = new JDialog();
                            jd.add(billFrame.getBillPanel());
                            jd.pack();
                            jd.setLocationRelativeTo(null);
                            jd.setVisible(true);
                        } else {
                            System.out.println("Failed");
                        }
                    }
                }
                pst.close();
                con.close();
            } catch (Exception e) {
                e.printStackTrace();
            }

        }
    }

//    เรียกเมนูที่จองไว้มาจาก Datebase
    public static ArrayList<Order> menuList(String sql, boolean mode) {
        if (mode) {
            adminBillList = new ArrayList<>();
            ClientModel.clientbillList = new ArrayList<>();
        } else {
            adminHistoryBill = new ArrayList<>();ClientModel.clientHistory = new ArrayList<>();
        }
        ArrayList<Order> menusList = new ArrayList<>();
        try {
            Connection con = DB.mycon();
            PreparedStatement pst = con.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();

            Order menu;
            while (rs.next()) {
                int queue = rs.getInt("id");
                Timestamp time = rs.getObject("time", Timestamp.class);
                byte[] st = (byte[]) rs.getObject("menu");
                ByteArrayInputStream baip = new ByteArrayInputStream(st);
                ObjectInputStream ois = new ObjectInputStream(baip);
                MenuKeep menuKeep = (MenuKeep) ois.readObject();
                String[] bill = menuKeep.billText(menuKeep.getTypeMenu(), menuKeep.getLineMenu(), menuKeep.getInd(), menuKeep.getEgg(), time.toString(), queue, menuKeep.getExtra(), menuKeep.getComnent());
                if (mode) {
                    ClientModel.clientbillList.add(bill);
                    AdminModel.adminBillList.add(bill);
                } else {
                    ClientModel.clientHistory.add(bill);
                    AdminModel.adminHistoryBill.add(bill);
                }
                menu = new Order(queue, time, menuKeep, rs.getString("name"));
                menusList.add(menu);
            }
            pst.close();
            rs.close();
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return menusList;
    }

//    set Model ให้ JTable
    public static void setTableModel(JTable table, String[] colName) {
        table.setModel(new DefaultTableModel( null, colName) {
            boolean[] canEdit = new boolean [] {
                    false, false, false, false, true
            };
            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
    }

}
