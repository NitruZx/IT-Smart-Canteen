package Database;

import ClientPage.ClientController;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class PassChangeController extends WindowAdapter {
    private PassChange passChange;

    public PassChangeController() {
        passChange = new PassChange();

        passChange.getFrame().addWindowListener(this);
    }

    @Override
    public void windowActivated(WindowEvent e) {
        ClientController.clientMain.userHeader.changeBtn.setEnabled(false);
        ClientController.clientMain.setEnabled(false);
    }

    @Override
    public void windowClosing(WindowEvent e) {
        ClientController.clientMain.userHeader.changeBtn.setEnabled(true);
        ClientController.clientMain.setEnabled(true);
    }
}
