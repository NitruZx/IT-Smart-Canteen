package Testing;

import at.favre.lib.crypto.bcrypt.BCrypt;

public class Test {

    public static void main(String args[]) {
        String password = "123456";
        String bcryptHashString = BCrypt.withDefaults().hashToString(12, password.toCharArray());

        System.out.println(bcryptHashString);
    }

}
