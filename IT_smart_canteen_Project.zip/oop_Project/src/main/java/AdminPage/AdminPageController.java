package AdminPage;

import com.formdev.flatlaf.themes.FlatMacLightLaf;
import java.awt.Color;
import java.awt.Container;
import java.awt.Graphics;
import java.awt.event.*;
import javax.swing.*;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author TarJ
 */
public class AdminPageController extends AdminModel implements ActionListener {

    public static AdminMain adminMain;
    public AdminModel adminModel;
    private int i;

    public AdminPageController() {
        this("");
    }

    public AdminPageController(String name) {
        adminMain = new AdminMain(name);
        adminModel = new AdminModel();

        adminModel.showMenu();
        btnOpenStatus();

        adminMain.startBtn.addActionListener(this);
        adminMain.refresh.addActionListener(this);
        adminMain.dequeue.addActionListener(this);
        adminMain.clearBtn.addActionListener(this);
    }

    public static void glassPane(boolean isShow) {
        adminMain.setGlassPane(new JComponent() {
            @Override
            protected void paintComponent(Graphics g) {
                g.setColor(new Color(0, 0, 0, 150));
                g.fillRect(0, 0, getWidth(), getHeight());
            }
        });
        Container glassPane = (Container) adminMain.getGlassPane();
        if (isShow) {
            glassPane.setVisible(true);
        } else {
            glassPane.setVisible(false);
        }
        glassPane.addMouseListener(new MouseAdapter() {
        });

    }

    private void btnChange() {
        if (!AdminMain.state) {
            adminModel.setState(!adminMain.state);
            adminMain.startBtn.setBackground(Color.red);
            adminMain.startBtn.setText("Reset");
            adminMain.manageBtn.setEnabled(!adminMain.state);

        } else {
            if (adminModel.resetQueue()) {
                adminModel.setState(!adminMain.state);
                adminMain.startBtn.setBackground(new Color(66, 220, 113));
                adminMain.startBtn.setText("Start Queue");
                adminMain.manageBtn.setEnabled(!adminMain.state);
            }
        }
    }

    private void btnOpenStatus() {
        SwingWorker worker = new SwingWorker() {
            @Override
            protected Object doInBackground() throws Exception {
                boolean state = AdminModel.stateCheck();
                AdminMain.state = state;
                if (state) {
                    adminMain.startBtn.setBackground(Color.red);
                    adminMain.startBtn.setText("Reset");
                    adminMain.manageBtn.setEnabled(false);
                }

                return null;
            }
        };
        worker.execute();
    }

    public static void showGlassPane(boolean isShow) {
        if (isShow) {
            glassPane(true);
        } else {
            glassPane(false);
        }
    }

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            UIManager.setLookAndFeel(new FlatMacLightLaf());
        } catch (Exception e) {
            e.printStackTrace();
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AdminPageController();
            }
        });
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == adminMain.refresh) {
            adminModel.showMenu();
        } else if (e.getSource() == adminMain.dequeue) {
            adminModel.dequeue();
        } else if (e.getSource() == adminMain.startBtn) {
            SwingWorker worker = new SwingWorker() {
                @Override
                protected Object doInBackground() throws Exception {
                    adminMain.statusText.setText("Loading status...");
                    AdminMain.loadingDialog.setVisible(true);
//                    adminModel.setState(!adminMain.state);
                    btnChange();
                    return null;
                }

                @Override
                protected void done() {
                    adminMain.statusText.setText("");
                    AdminMain.loadingDialog.dispose();
                }
            };
            worker.execute();
        } else if (e.getSource() == adminMain.clearBtn) {
            int option = JOptionPane.showOptionDialog(null, "Are you sure to clear Queue?", "Clear Queue", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, null, 0);
            if (option == 0) {
                SwingWorker worker = new SwingWorker() {
                    @Override
                    protected Object doInBackground() throws Exception {
                        AdminMain.loadingDialog.setVisible(true);
                        if (runSQLQuery("TRUNCATE TABLE queue", "ClearTable failed")) {
                            JOptionPane.showMessageDialog(null, "Success", "", JOptionPane.PLAIN_MESSAGE);
                        }
                        return null;
                    }
                    @Override
                    protected void done() {
                        AdminMain.loadingDialog.dispose();
                    }
                };
                worker.execute();

            }
        }
    }
}
