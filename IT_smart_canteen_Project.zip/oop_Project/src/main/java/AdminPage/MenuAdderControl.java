package AdminPage;

import javax.swing.*;
import javax.swing.event.InternalFrameEvent;
import javax.swing.event.InternalFrameListener;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class MenuAdderControl extends MenuAdderModel implements ActionListener, InternalFrameListener {
    public MenuAdder menuAdder;

    public MenuAdderControl() {
        menuAdder = new MenuAdder();
        pullFromDB(menuAdder.jTable1);

        menuAdder.importBtn.addActionListener(this);
        menuAdder.updateBtn.addActionListener(this);
        menuAdder.addBtn.addActionListener(this);
        menuAdder.deleteBtn.addActionListener(this);
        menuAdder.refreshBtn.addActionListener(this);
        menuAdder.addInternalFrameListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == menuAdder.importBtn) {
            excelLoad(menuAdder.jTable1);
        } else if (e.getSource() == menuAdder.updateBtn) {
            SwingWorker worker = new SwingWorker() {
                @Override
                protected Object doInBackground() throws Exception {
                    AdminMain.loadingDialog.setVisible(true);
                    updateBtnFunc();
                    return null;
                }

                @Override
                protected void done() {
                    AdminMain.loadingDialog.dispose();
                    JOptionPane.showMessageDialog(null, "Finish update", "Finish", JOptionPane.PLAIN_MESSAGE);
                }
            };
            worker.execute();
        } else if (e.getSource() == menuAdder.addBtn) {
            addMenu(menuAdder.menuField.getText());
        } else if (e.getSource() == menuAdder.deleteBtn) {
            deleteMenu();
        } else if (e.getSource() == menuAdder.refreshBtn) {
            pullFromDB(menuAdder.jTable1);
        }
    }

    public void updateBtnFunc() {
        try {
            int option = JOptionPane.showOptionDialog(null, "Do you want to replacing exists table?", "Update Table", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, null, 0);
            if (option == 0) {
                truncateDBTable();
            }
            SwingWorker worker = new SwingWorker() {
                @Override
                protected Object doInBackground() throws Exception {
                    AdminMain.loadingDialog.setVisible(true);
                    insertTODB();
                    return null;
                }
                @Override
                protected void done() {
                    AdminMain.loadingDialog.dispose();
                }
            };
            worker.execute();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void addMenu(String menu) {
        if (menuAdder.menuField.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Plesase insert menu name", "Add menu", JOptionPane.WARNING_MESSAGE);
            return;
        }
        DefaultTableModel model = (DefaultTableModel) menuAdder.jTable1.getModel();
        lastRow += 1;
        SwingWorker worker = new SwingWorker() {
            @Override
            protected Object doInBackground() throws Exception {
                AdminMain.loadingDialog.setVisible(true);
                try {
                    Connection con = mycon();
                    PreparedStatement pst = con.prepareStatement("INSERT INTO menu (name) VALUES ('"+menu+"')");
                    int work = pst.executeUpdate();
                    if (work > 0) {
                        model.addRow(new Object[] {menu});
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
                return null;
            }

            @Override
            protected void done() {
                AdminMain.loadingDialog.dispose();
            }
        };
        worker.execute();
    }

    public void deleteMenu() {
        int option = JOptionPane.showOptionDialog(null, "Do you sure to delete menu?", "Update Table", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, null, 0);
        if (option == 0 && (menuAdder.jTable1.getSelectedRow() >= 0)) {
            if (deleteRow(menuAdder.jTable1)) {
                JOptionPane.showMessageDialog(null, "Delete Success", "Success", JOptionPane.PLAIN_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "Delete Failed", "ERROR", JOptionPane.PLAIN_MESSAGE);
            }
        }
    }

    @Override
    public void internalFrameOpened(InternalFrameEvent e) {
        ManageFrame.menuBtn.setEnabled(false);
    }

    @Override
    public void internalFrameClosing(InternalFrameEvent e) {
        ManageFrame.menuBtn.setEnabled(true);
    }

    @Override
    public void internalFrameClosed(InternalFrameEvent e) {

    }

    @Override
    public void internalFrameIconified(InternalFrameEvent e) {

    }

    @Override
    public void internalFrameDeiconified(InternalFrameEvent e) {

    }

    @Override
    public void internalFrameActivated(InternalFrameEvent e) {

    }

    @Override
    public void internalFrameDeactivated(InternalFrameEvent e) {

    }
}
