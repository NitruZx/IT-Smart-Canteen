package AdminPage;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
import java.io.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class MenuAdderModel extends AdminModel{
    private ArrayList<String> menuList;
    public int lastRow;
    public void excelLoad(JTable table) {
        DefaultTableModel model = (DefaultTableModel) table.getModel();
        JFileChooser openFile = new JFileChooser();
        openFile.setDialogTitle("Open File");
        openFile.removeChoosableFileFilter(openFile.getFileFilter());
        FileNameExtensionFilter filter = new FileNameExtensionFilter("Excel File (.xlsx)", "xlsx");
        openFile.setFileFilter(filter);
        int excelChooser = openFile.showOpenDialog(null);
        if (excelChooser == JFileChooser.APPROVE_OPTION) {
            model.setRowCount(0);
            menuList = new ArrayList<>();
            File excelFile = openFile.getSelectedFile();
            try (FileInputStream excelFIS = new FileInputStream(excelFile)){
                XSSFWorkbook excelWorkbook = new XSSFWorkbook(excelFIS);
                XSSFSheet excelSheet = excelWorkbook.getSheetAt(0);
                for (int i = 0; i < excelSheet.getLastRowNum()+1; i++) {
                    XSSFRow excelRow = excelSheet.getRow(i);
                    XSSFCell excelMenu = excelRow.getCell(0);
                    model.addRow(new Object[] {excelMenu});
                    String menu = String.valueOf(excelMenu);
                    menuList.add(menu);
                }
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public void pullFromDB(JTable table) {
        SwingWorker worker = new SwingWorker() {
            @Override
            protected Object doInBackground() throws Exception {
                AdminMain.loadingDialog.setVisible(true);
                DefaultTableModel model = (DefaultTableModel) table.getModel();
                model.setRowCount(0);
                try {
                    Connection con = mycon();
                    String sql = "SELECT * FROM menu";
                    PreparedStatement pst = con.prepareStatement(sql);
                    ResultSet rs = pst.executeQuery();
                    while (rs.next()) {
                        String name = rs.getString("name");
                        model.addRow(new Object[] {name});
                    }
                    rs.close();
                    pst.close();
                    con.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
                return null;
            }
            @Override
            protected void done() {
                AdminMain.loadingDialog.dispose();
            }
        };
        worker.execute();
    }

    public void insertTODB() throws SQLException {
        Connection con = mycon();
        String sql = "INSERT INTO menu (name) VALUES (?)";
        PreparedStatement pst = con.prepareStatement(sql);
        for (int i = 0; menuList.size() > i;i++) {
                pst.setString(1, menuList.get(i));
                pst.executeUpdate();
        }
    }

    public void truncateDBTable() throws SQLException{
        Connection con = mycon();
        String sql = "TRUNCATE TABLE menu";
        PreparedStatement pst = con.prepareStatement(sql);
        pst.executeUpdate();
        pst.close();
        con.close();
    }

    public boolean deleteRow(JTable table) {
        DefaultTableModel model = (DefaultTableModel) table.getModel();
        int row = table.getSelectedRow();
        String menu = (String) model.getValueAt(row, 0);
        try {
            Connection con = mycon();
            PreparedStatement pst = con.prepareStatement("DELETE FROM menu WHERE name='"+menu+"'");
            pst.executeUpdate();
            model.removeRow(row);
            pst.close();
            con.close();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

}
