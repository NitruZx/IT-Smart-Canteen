package LoginPage;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class SignPageController extends SignUpPageModel implements ActionListener {
    private SignUpGUI signUpGUI;
    private Container glasspane;

    public SignPageController() {
        signUpGUI = new SignUpGUI();

        signUpGUI.frame.setGlassPane(new JComponent() {
            @Override
            protected void paintComponent(Graphics g) {
                g.setColor(new Color(0, 0, 0, 150));
                g.fillRect(0, 0, getWidth(), getHeight());
            }
        });
        LoginGUI.frame.getGlassPane().addMouseListener(new MouseAdapter() {
        });

        glasspane = (Container) signUpGUI.frame.getGlassPane();
        signUpGUI.signupBtn.addActionListener(this);
        signUpGUI.backBtn.addActionListener(this);
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == signUpGUI.signupBtn) {
            SwingWorker worker = new SwingWorker() {
                @Override
                protected Object doInBackground() throws Exception {
                    signUpGUI.loadScreen.setVisible(true);
                    glasspane.setVisible(true);
                    registerUser(signUpGUI.nameField.getText(), signUpGUI.emailField.getText(), String.valueOf(signUpGUI.passField1.getPassword()), String.valueOf(signUpGUI.passField2.getPassword()));
                    return null;
                }

                @Override
                protected void done() {
                    glasspane.setVisible(false);
                    signUpGUI.loadScreen.setVisible(false);
                }
            };
            worker.execute();
        } else if (e.getSource().equals(signUpGUI.backBtn)) {
            new Main();
            signUpGUI.frame.dispose();
        }
    }

    public static void main(String[] args) {
        try {
//            UIManager.setLookAndFeel(new Flat);
        } catch (Exception e) {
            e.printStackTrace();
        }
        new SignPageController();
    }


}
