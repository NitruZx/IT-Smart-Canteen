package LoginPage;

import AdminPage.AdminPageController;
import Database.UserManage;
import com.cell.loadingDialog.LoginLoad;
import ian.PassFieldCtm;
import ian.CustomField;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SellerPanel extends LoginModel implements ActionListener {
    private JPanel centerMain, buttPanel, textPanel;
    private JButton loginButt;
    private CustomField username;
    private PassFieldCtm password;
    private Color color = new Color(145, 3, 216);
    private LoginLoad loadScreen;
    public SellerPanel() {
        centerMain = new JPanel();
        centerMain.setLayout(new GridLayout(3, 1));

        loadScreen = new LoginLoad(LoginGUI.frame);

        textPanel = new JPanel();
        textPanel.setLayout(new GridLayout(2, 1));
        buttPanel = new JPanel();

        username = new CustomField();
        password = new PassFieldCtm();
        username.setLabelText("Admin user");username.setLineColor(color);username.setSelectionColor(new Color(188, 142, 218));
        password.setLabelText("Password");password.setLineColor(color);password.setSelectionColor(new Color(188, 142, 218));

        loginButt = new JButton("Login");
        buttPanel.add(loginButt);
        textPanel.setBorder(new EmptyBorder(0, 30, 0, 30));
        textPanel.add(username);textPanel.add(password);

        centerMain.add(textPanel);centerMain.add(buttPanel);
        centerMain.setBorder(new EmptyBorder(80, 60, 20, 60));
        loginButt.addActionListener(this);
    }

    public JPanel getCenterMain() {
        return centerMain;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == loginButt) {
            String name = username.getText();
            String pass = String.valueOf(password.getPassword());
            SwingWorker worker = new SwingWorker() {
                @Override
                protected Object doInBackground() throws Exception {
                    loadScreen.setVisible(true);
                    LoginGUI.frame.getGlassPane().setVisible(true);
                    if (login(name, pass, " SELECT * FROM admin WHERE Name=? LIMIT 1")) {
                        LoginGUI.frame.dispose();
                        AdminPageController adminPage = new AdminPageController("Admin");
                    }
                    return null;
                }

                @Override
                protected void done() {
                    LoginGUI.frame.getGlassPane().setVisible(false);
                    loadScreen.setVisible(false);
                }
            };
            worker.execute();

        }
    }
}
