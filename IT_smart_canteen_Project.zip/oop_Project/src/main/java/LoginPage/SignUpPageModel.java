package LoginPage;

import Database.UserManage;

import javax.swing.*;

public class SignUpPageModel extends UserManage {
    public UserInfo user;

    //register
    public void registerUser(String name, String email, String password, String password2) {
        if (name.isEmpty() || email.isEmpty() || password.isEmpty() || password2.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Please enter all fields", "Sign-up", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (name.length() < 4) {
            JOptionPane.showMessageDialog(null, "Username must at least 4 character!!!", "Sign-up", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (password.length() < 6) {
            JOptionPane.showMessageDialog(null, "Password must at least 6 character!!!", "Sign-up", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (!password.equals(password2)) {
            JOptionPane.showMessageDialog(null, "Comfirm password does not match", "Sign-up", JOptionPane.ERROR_MESSAGE);
            return;
        }

        user = addUserToDB(name, email, password);
        if (user != null) {
            JOptionPane.showMessageDialog(null, "Create Account Success!", "Success", JOptionPane.PLAIN_MESSAGE);
        } else {
            System.out.println("Failed to create account");
        }
    }
}
