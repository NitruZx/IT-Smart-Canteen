package LoginPage;

import Database.DB;
import Database.UserManage;

import javax.swing.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class LoginModel extends UserManage {

    // Login Method
    public boolean login(String name, String password, String sql) {
        try {
            Connection con = DB.mycon();
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, name); //username
            ResultSet rs  = pst.executeQuery();
            if (rs.next()) {
                if (checkPassword(password, rs.getString("Password"))) {
                    return true;
                } else {
                    JOptionPane.showMessageDialog(null, "wrong password", "Login", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(null, "Username not Found", "Login", JOptionPane.ERROR_MESSAGE);
            }
            con.close();
        } catch (Exception e) {
            e.printStackTrace();

        }
        return false;
    }
}
