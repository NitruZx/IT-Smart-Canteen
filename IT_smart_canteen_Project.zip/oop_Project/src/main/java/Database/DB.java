package Database;

import javax.swing.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class DB {

    //คำสั่งเรียก Connection จาก Datebase
    public static Connection mycon() {
        Connection con = null;
        final String DB_URL = "jdbc:mysql://db4free.net:3306/kinsabye";
        final String Username = "nitruzx";
        final String Password = "tj08706772308211";
        try {
            con = DriverManager.getConnection(DB_URL, Username, Password);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return con;
    }

    // execute Query ที่กำหนด
    public boolean runSQLQuery(String sql, String errorString) {
        try {
            Connection con = mycon();
            PreparedStatement pst = con.prepareStatement(sql);
            pst.executeUpdate();
            pst.close();
            con.close();
            return true;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, errorString, "", JOptionPane.ERROR_MESSAGE);
        }
        return false;
    }

}
