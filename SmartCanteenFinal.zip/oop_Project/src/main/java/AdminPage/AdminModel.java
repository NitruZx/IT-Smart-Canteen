/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AdminPage;

import static AdminPage.AdminPageController.showGlassPane;

import Database.BillFrame;
import Database.DB;
import Database.MiddleSystem;
import Database.Order;
import Queuefunc.QueueTable;
import com.cell.TableActionEvent;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.SwingWorker;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author TarJ
 */
public class AdminModel extends MiddleSystem {

    public static ArrayList<String[]> adminBillList, adminHistoryBill;

    public void showMenu() {
        TableActionEvent event = new TableActionEvent() {

            @Override
            public void onView(int row) {
                String[] text = adminBillList.get(row);
                BillFrame bill = new BillFrame();
                bill.setBillText(text);
                bill.setVisible(true);
            }
        };
        SwingWorker worker = new SwingWorker() {

            @Override
            protected Object doInBackground() throws Exception {
                showGlassPane(true);
                AdminMain.loadingDialog.setVisible(true);
                ArrayList<Order> list = menuList(" SELECT * FROM queue", true);
                QueueTable queueTable = new QueueTable();
                DefaultTableModel model = (DefaultTableModel) queueTable.table.getModel();
                Object[] row = new Object[4];
                for (int i = 0; i < list.size(); i++) {
                    row[0] = String.format("%03d", list.get(i).getQueue());
                    row[1] = list.get(i).getTime().toString();
                    row[2] = list.get(i).getMenu().getTypeMenu();
                    row[3] = list.get(i).getName();
                    model.addRow(row);
                }
                AdminMain.queueTable.table.setModel(model);
                tableEvent(AdminMain.queueTable.table, 4, event);
                return null;
            }

            @Override
            protected void done() {
                showGlassPane(false);
                AdminMain.loadingDialog.dispose();
            }
        };
        worker.execute();

    }

    @Override
    public void updateHistory() {

    }

    public void dequeue() {
        SwingWorker workder = new SwingWorker() {
            @Override
            protected Object doInBackground() throws Exception {
                AdminMain.deleteDialog.setVisible(true);
                try {
                    Connection con = DB.mycon();
                    String sql = "DELETE FROM queue LIMIT 1";
                    PreparedStatement pst = con.prepareStatement(sql);
                    pst.executeUpdate();
                    showMenu();
                } catch (Exception e) {
                    e.printStackTrace();
                }

                return null;
            }

            @Override
            protected void done() {
                AdminMain.deleteDialog.dispose();
            }

        };
        workder.execute();
    }

    public static void clearTable() {
        AdminMain.queueTable.table.setModel(new QueueTable().table.getModel());
    }

    public void setState(Boolean state) {
        AdminMain.state = state;
        try {
            Connection con = DB.mycon();
            String sql = "UPDATE res_state SET state=? WHERE name=?";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setBoolean(1, state);
            pst.setString(2, "smartcanteen");
            pst.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static boolean stateCheck() {
        try {
            Connection con = DB.mycon();
            String sql = " SELECT * FROM res_state WHERE name=?";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, "smartcanteen");
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                boolean state = rs.getBoolean("state");
                return state;
            }
            rs.close();
            pst.close();
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean resetQueue() {
        int option = JOptionPane.showOptionDialog(null, "Reseting Queue?", "Confirm", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, null, 0);
        int count = 0;
        if (option == 0) {
            try {
                Connection con = DB.mycon();
                PreparedStatement ps = con.prepareStatement("SELECT id FROM queue LIMIT 1");
                ResultSet rs = ps.executeQuery();
                if (!rs.next()) {
                    String sql = "ALTER TABLE queue AUTO_INCREMENT = 1";
                    PreparedStatement pst = con.prepareStatement(sql);
                    pst.executeUpdate();
                    System.out.println("reseting");
                    return true;
                } else {
                    JOptionPane.showMessageDialog(null, "Queue is not empty", "Error", JOptionPane.ERROR_MESSAGE);
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        } 
        return false;
    }
}
