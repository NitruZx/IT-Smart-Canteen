/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ClientPage;

import AdminPage.AdminModel;
import Database.BillFrame;
import Database.MiddleSystem;
import Database.Order;
import com.cell.TableActionEvent;

import java.util.ArrayList;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author TarJ
 */
public class ClientModel extends MiddleSystem {

    public static ArrayList<String[]> clientbillList, clientHistory;

    public void showMenu() {
        SwingWorker worker = new SwingWorker() {
            @Override
            protected Object doInBackground() throws Exception {
                ClientController.showGlassPane(true);
                ClientMain.loadingDialog.setVisible(true);
                ArrayList<Order> list = menuList(" SELECT * FROM queue", true);
                setTableModel(ClientMain.queueTable.table, new String[]{"Queue", "Time", "Menu", "Name"});
                DefaultTableModel model = (DefaultTableModel) ClientMain.queueTable.table.getModel();
                Object[] row = new Object[4];
                for (int i = 0; i < list.size(); i++) {
                    row[0] = String.format("%03d", list.get(i).getQueue());
                    row[1] = list.get(i).getTime().toString();
                    row[2] = list.get(i).getMenu().getTypeMenu();
                    row[3] = list.get(i).getName();
                    model.addRow(row);
                }
                ClientController.isOpen = AdminModel.stateCheck();
                ClientController.orderBtnState();

                return null;
            }

            @Override
            protected void done() {
                ClientController.showGlassPane(false);
                ClientMain.loadingDialog.dispose();
            }

        };
        worker.execute();
    }

    public void updateHistory() {
        TableActionEvent event = new TableActionEvent() {
            @Override
            public void onView(int row) {
                String[] text = ClientModel.clientHistory.get((ClientModel.clientHistory.size() - 1) - row);
                BillFrame bill = new BillFrame();
                bill.setVisible(true);
                bill.setBillText(text);
            }
        };
        SwingWorker worker = new SwingWorker() {
            @Override
            protected Object doInBackground() throws Exception {
                ArrayList<Order> list = menuList(" SELECT * FROM admin_his WHERE name IN ('" + ClientController.name + "')", false);
                ClientMain.recentPage.table.setModel(new DefaultTableModel( null,  new String [] {"Time", "Menu", "Price", ""}
                ) { boolean[] canEdit = new boolean [] {
                        false, false, false, true
                };
                    public boolean isCellEditable(int rowIndex, int columnIndex) {
                        return canEdit [columnIndex];
                    }
                });
                DefaultTableModel model = (DefaultTableModel) ClientMain.recentPage.table.getModel();
                Object[] row = new Object[4];
                for (int i = list.size() - 1; i >= 0; i--) {
                    row[0] = list.get(i).getTime();
                    row[1] = list.get(i).getMenu().getTypeMenu();
                    row[2] = list.get(i).getMenu().getMoney();
                    model.addRow(row);
                }
                tableEvent(ClientMain.recentPage.table, 3, event);
                return null;
            }
        };
        worker.execute();
    }
}
