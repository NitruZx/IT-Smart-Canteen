package Database;

import com.cell.Button;
import ian.CustomField;
import ian.PassFieldCtm;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;

public class PassChange {

    private JFrame frame;
    public Button verifyBtn, changeBtn;
    private JLabel text, keyPic;
    public JPanel topPanel, mainPanel, cardPanel, settPanel, btnPanel, changeBtnPnl, framePanel;
    public CustomField emailField;
    public PassFieldCtm oldPassField, newPassField, conNewPass;
    public CardLayout cardLayout = new CardLayout();
    public Container glassPane;
    public PassChange() {
        frame = new JFrame("Change Password");
        framePanel = new JPanel();framePanel.setLayout(new BorderLayout());

//      icon =============================
        ImageIcon icon = new ImageIcon("src/main/java/Icon/keywhite.png");
        Image img = icon.getImage();
        Image newimg = img.getScaledInstance(45, 50, Image.SCALE_SMOOTH);
        ImageIcon keyIcon = new ImageIcon(newimg);
//        ================================

        EmptyBorder emptyBorder = new EmptyBorder(12, 0, 0, 0);
        text = new JLabel("Change Password");text.setForeground(Color.WHITE);text.setFont( new Font("Verdana", 1, 18));
        text.setBorder(emptyBorder);
        keyPic = new JLabel(keyIcon);
        keyPic.setBorder(emptyBorder);
        topPanel = new JPanel();topPanel.setPreferredSize(new Dimension(100, 80));
        topPanel.setBackground(new Color(52, 50, 50));
        topPanel.add(keyPic);topPanel.add(text);

        cardPanel = new JPanel();
        cardPanel.setLayout(cardLayout);

        btnPanel = new JPanel();
        btnPanel.setBorder(new EmptyBorder(8, 0, 0, 0));
        btnPanel.setOpaque(false);

        mainPanel = new JPanel();mainPanel.setBackground(Color.white);
        mainPanel.setLayout(new GridLayout(3, 1));
        mainPanel.setBorder(new EmptyBorder(30, 50, 50, 50));
        emailField = new CustomField();emailField.setLabelText("Email");emailField.setLineColor(new Color(240, 35, 76 ));
        oldPassField = new PassFieldCtm();oldPassField.setLabelText("Current Password");oldPassField.setLineColor(new Color(240, 35, 76 ));
        verifyBtn = new Button();btnPanel.add(verifyBtn);
        verifyBtn.setBackground(new Color(243, 129, 129));
        verifyBtn.setForeground(new Color(255, 255, 255));
        verifyBtn.setShadowColor(new Color(82, 82, 82));
        verifyBtn.setRound(20);
        verifyBtn.setText("Verify");

        mainPanel.add(emailField);mainPanel.add(oldPassField);mainPanel.add(btnPanel);

        settPanel = new JPanel();settPanel.setBackground(Color.white);
        settPanel.setLayout(new GridLayout(3, 1));
        settPanel.setBorder(new EmptyBorder(30, 50, 40, 50));
        changeBtnPnl = new JPanel();changeBtnPnl.setBorder(new EmptyBorder(10, 0, 0, 0));changeBtnPnl.setOpaque(false);
        newPassField = new PassFieldCtm();newPassField.setLabelText("New Password(at least 6 character)");
        conNewPass = new PassFieldCtm();conNewPass.setLabelText("Confirm Password");
        changeBtn = new Button();changeBtn.setText("Change Password");changeBtn.setBackground(new Color(26, 208, 98));
        changeBtn.setForeground(Color.white);
        changeBtn.setShadowColor(new Color(82, 82, 82));
        changeBtnPnl.add(changeBtn);
        settPanel.add(newPassField);settPanel.add(conNewPass);settPanel.add(changeBtnPnl);

        cardPanel.add(mainPanel, "main");
        cardPanel.add(settPanel, "set");
        cardLayout.show(cardPanel, "main");

        frame.setGlassPane(new JComponent() {
            @Override
            protected void paintComponent(Graphics g) {
                g.setColor(new Color(0, 0, 0, 150));
                g.fillRect(0, 0, getWidth(), getHeight());
            }
        });
        glassPane = (Container) frame.getGlassPane();
        glassPane.addMouseListener(new MouseAdapter() {
        });

        framePanel.add(topPanel, BorderLayout.NORTH);framePanel.add(cardPanel, BorderLayout.CENTER);
        frame.add(framePanel);
        frame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        frame.setResizable(false);
        frame.setSize(350, 380);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
    public JFrame getFrame() {
        return frame;
    }
}
