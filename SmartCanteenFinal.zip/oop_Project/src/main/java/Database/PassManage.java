package Database;

public interface PassManage {

    public abstract void verifyPass();
    public abstract void changePass();

}
