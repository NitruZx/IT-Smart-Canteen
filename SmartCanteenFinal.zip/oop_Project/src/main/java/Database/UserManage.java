package Database;

import LoginPage.UserInfo;
import at.favre.lib.crypto.bcrypt.BCrypt;

import javax.swing.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class UserManage extends DB{
    public boolean login(String name, String password, String sql) {
        try {
            Connection con = mycon();
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, name); //username
            ResultSet rs  = pst.executeQuery();
            if (rs.next()) {
                if (DB.checkPassword(password, rs.getString("Password"))) {
                    return true;
                } else {
                    JOptionPane.showMessageDialog(null, "wrong password", "Login", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(null, "Username not Found", "Login", JOptionPane.ERROR_MESSAGE);
            }
            con.close();
        } catch (Exception e) {
            e.printStackTrace();

        }
        return false;
    }
    public UserInfo addUserToDB(String name, String email, String password) {
        UserInfo user = null;
        String hashPass = DB.getHash(password);
        try {
            Connection conn = DB.mycon();
            PreparedStatement pst = conn.prepareStatement(" SELECT * FROM users WHERE Name=? LIMIT 1");
            pst.setString(1, name);
            ResultSet rs = pst.executeQuery();
            if (!rs.next()) {
                Statement stmt = conn.createStatement();
                String sql = "INSERT INTO users (Name, Email, Password) VALUES (?, ?, ?)";
                PreparedStatement preparedStatement = conn.prepareStatement(sql);
                preparedStatement.setString(1, name);
                preparedStatement.setString(2, email);
                preparedStatement.setString(3, hashPass);

                int addedRows = preparedStatement.executeUpdate();
                if (addedRows > 0) {
                    user = new UserInfo();
                    user.setName(name);
                    user.setEmail(email);
                    user.setPassword(hashPass);
                }

                stmt.close();
                conn.close();
            } else {
                JOptionPane.showMessageDialog(null, "Username already exists!", "Sign-up", JOptionPane.ERROR_MESSAGE);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return user;
    }
    public boolean verfifyPass(String name, String email, String oldPass, String sql) {
        try {
            Connection conn = mycon();
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, name);
            pst.setString(2, email);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                if (DB.checkPassword(oldPass, rs.getString("Password"))) {
                    return true;
                } else {
                    JOptionPane.showMessageDialog(null , "Wrong password", "Verify ERROR", JOptionPane.ERROR_MESSAGE);
                }

            } else {
                JOptionPane.showMessageDialog(null, "Please insert registered email", "Verify ERROR", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
    public void updateUserPassword(String table, String oldPass, String newPass, String confirmPass, String name) {
        if (newPass.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Please insert new password", "", JOptionPane.ERROR_MESSAGE);
        } else if (newPass.equals(oldPass)) {
            JOptionPane.showMessageDialog(null, "New password can't be the same as old");
        } else if (newPass.length() < 6) {
            JOptionPane.showMessageDialog(null, "Please insert at-least 6 character.");
        } else if (!newPass.equals(confirmPass)) {
            JOptionPane.showMessageDialog(null, "Confirm password do not match", "", JOptionPane.ERROR_MESSAGE);
        } else {
            String password = DB.getHash(newPass);
            runSQLQuery("UPDATE "+table+" SET Password='"+password+"' WHERE name='"+ name +"'", "Password Change Failed");
            JOptionPane.showMessageDialog(null, "Password change success.", "Success", JOptionPane.PLAIN_MESSAGE);
        }


    }
}
