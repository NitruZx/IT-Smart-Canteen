package Database;

import ClientPage.NoodleOrder.MenuKeep;
import java.awt.BorderLayout;
//import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.io.Serializable;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.WindowConstants;
import javax.swing.border.EmptyBorder;

public class Bill implements Serializable{

    public MenuKeep menuKeeping2;

    private final JFrame mFrame;
    private final JPanel bg, show, spitOT, menu, total;
    private JTextField b;
    private final JLabel brand, nameStore, date, menuName, menuInd, menuEgg, menuHead, thankText, order, totalText1, totalText2;
    private final Font billFont, menuFont;
//    private String[] text = new String[3];
    
    public Bill() {
        this(null);
    }
    
    public Bill(String[] text) {
        billFont = new Font("Tahoma", Font.PLAIN, 18);
        mFrame = new JFrame("It Smart Canteen");
        bg = new JPanel();
        bg.setLayout(new BorderLayout());
        show = new JPanel();
        brand = new JLabel("IT Smart Canteen", JLabel.CENTER);
        brand.setFont(billFont);
        nameStore = new JLabel("Kinsabye~~", JLabel.CENTER);
        nameStore.setFont(billFont);
        spitOT = new JPanel(new GridLayout(1, 2));
        order = new JLabel("Order "+text[5], JLabel.LEFT);
        order.setFont(billFont);
        date = new JLabel("Date : ", JLabel.LEFT);
        date.setText("Date/Time : " + text[3]);
        date.setBorder(new EmptyBorder(0, 10, 0, 10));
        date.setFont(billFont);
        menu = new JPanel(new GridLayout(3, 1));
        
        menuFont = new Font("TH SarabunPSK", Font.BOLD, 22);
        
        menuName = new JLabel();
        menuInd = new JLabel();
        menuEgg = new JLabel();
        menu.add(menuName);menu.add(menuInd);menu.add(menuEgg);
        
        menuName.setText(text[0]);
        menuName.setFont(menuFont);
        menuInd.setText(text[1]);
        menuInd.setFont(menuFont);
        menuEgg.setText(text[2]);
        menuEgg.setFont(menuFont);
        

        menuHead = new JLabel("Menu", JLabel.LEFT);
        menuHead.setBorder(new EmptyBorder(0, 10, 0, 10));
        menuHead.setFont(billFont);
        total = new JPanel(new GridLayout(1, 3));

        totalText1 = new JLabel("Total", JLabel.LEFT);
        totalText2 = new JLabel(text[4], JLabel.RIGHT);
        thankText = new JLabel("* Thankyou for using the service *", JLabel.CENTER);
        thankText.setBorder(new EmptyBorder(0, 10, 10, 10));
        totalText1.setFont(billFont);
        totalText2.setFont(billFont);
        thankText.setFont(billFont);

        bg.add(thankText, BorderLayout.SOUTH);
        show.setLayout(new GridLayout(8, 1));

        spitOT.setBorder(new EmptyBorder(0, 10, 0, 10));
        spitOT.add(order);

        total.setBorder(new EmptyBorder(0, 10, 0, 10));
        total.add(totalText1);
        total.add(totalText2);

        show.add(brand);
        show.add(nameStore);
        show.add(date);
        show.add(spitOT);
        show.add(menuHead);
        show.add(menu);

        show.add(total);

        bg.add(show, BorderLayout.CENTER);
        mFrame.add(bg);

        mFrame.setVisible(true);
        //mFrame.setSize(540, 720
        //mFrame.setSize(1024, 768);
        mFrame.setResizable(false);
        mFrame.pack();
        mFrame.setLocationRelativeTo(null);
        mFrame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
    }
    
    
    public static void main(String[] args) {

        new Bill();
    }
}
