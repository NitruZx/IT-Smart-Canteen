package LoginPage.Slide;

import com.formdev.flatlaf.themes.FlatMacLightLaf;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TestMain implements ActionListener{
    private PanelSlide panelSlide = new PanelSlide();
    private JFrame frame;
    private JButton btn1, btn2;
    private JPanel panel1, panel2, btnPanel;
    public TestMain() {
        frame = new JFrame("Title");
        frame.setLayout(new BorderLayout());
        panel1 = new JPanel();
        panel2 = new JPanel();
        panel1.setBackground(Color.BLUE);
        panel2.setBackground(Color.RED);
        panelSlide.init(panel1, panel2);
        panelSlide.setAnimateSpeed(5);

        btnPanel = new JPanel();
        btnPanel.setLayout(new GridLayout(1, 2));
        btn1 = new JButton("1");
        btn2 = new JButton("2");
        btnPanel.add(btn1);btnPanel.add(btn2);

        btn1.addActionListener(this);
        btn2.addActionListener(this);

        frame.add(btnPanel, BorderLayout.SOUTH);
        frame.add(panelSlide, BorderLayout.CENTER);

        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setSize(400, 600);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);


    }

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(new FlatMacLightLaf());
        } catch (Exception e) {
            e.printStackTrace();
        }
        new TestMain();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btn1) {
            panelSlide.show(0);
            System.out.println("1");
        } else {
            panelSlide.show(1);
            System.out.println("2");
        }
    }
}
