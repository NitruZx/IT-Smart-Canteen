package LoginPage;

import Database.DB;
import Database.UserManage;

import javax.swing.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class SignUpPageModel extends UserManage {
    public UserInfo user;

//    public UserInfo addUserToDB(String name, String email, String password) {
//        UserInfo user = null;
//        String hashPass = DB.getHash(password);
//        try {
//            Connection conn = DB.mycon();
//            PreparedStatement pst = conn.prepareStatement(" SELECT * FROM users WHERE Name=? LIMIT 1");
//            pst.setString(1, name);
//            ResultSet rs = pst.executeQuery();
//            if (!rs.next()) {
//                Statement stmt = conn.createStatement();
//                String sql = "INSERT INTO users (Name, Email, Password) VALUES (?, ?, ?)";
//                PreparedStatement preparedStatement = conn.prepareStatement(sql);
//                preparedStatement.setString(1, name);
//                preparedStatement.setString(2, email);
//                preparedStatement.setString(3, hashPass);
//
//                int addedRows = preparedStatement.executeUpdate();
//                if (addedRows > 0) {
//                    user = new UserInfo();
//                    user.setName(name);
//                    user.setEmail(email);
//                    user.setPassword(hashPass);
//                }
//
//                stmt.close();
//                conn.close();
//            } else {
//                JOptionPane.showMessageDialog(null, "Username already exists!", "Sign-up", JOptionPane.ERROR_MESSAGE);
//            }
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//
//        return user;
//    }
//
//    public static boolean verfifyPass(String name, String email, String oldPass, String sql) {
//        try {
//            Connection conn = DB.mycon();
//            PreparedStatement pst = conn.prepareStatement(sql);
//            pst.setString(1, name);
//            pst.setString(2, email);
//            ResultSet rs = pst.executeQuery();
//            if (rs.next()) {
//                if (DB.checkPassword(oldPass, rs.getString("Password"))) {
//                    return true;
//                } else {
//                    JOptionPane.showMessageDialog(null , "Wrong password", "Verify ERROR", JOptionPane.ERROR_MESSAGE);
//                }
//
//            } else {
//                JOptionPane.showMessageDialog(null, "Please insert registered email", "Verify ERROR", JOptionPane.ERROR_MESSAGE);
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return false;
//    }
    public void registerUser(String name, String email, String password, String password2) {
        if (name.isEmpty() || email.isEmpty() || password.isEmpty() || password2.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Please enter all fields", "Sign-up", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (name.length() < 4) {
            JOptionPane.showMessageDialog(null, "Username must at least 4 character!!!", "Sign-up", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (password.length() < 6) {
            JOptionPane.showMessageDialog(null, "Password must at least 6 character!!!", "Sign-up", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (!password.equals(password2)) {
            JOptionPane.showMessageDialog(null, "Comfirm password does not match", "Sign-up", JOptionPane.ERROR_MESSAGE);
            return;
        }

        user = addUserToDB(name, email, password);
        if (user != null) {
            JOptionPane.showMessageDialog(null, "Create Account Success!", "Success", JOptionPane.PLAIN_MESSAGE);
        } else {
            System.out.println("Failed to create account");
        }
    }
}
